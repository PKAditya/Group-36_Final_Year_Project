"use strict";

var fs        = require("fs");
var path      = require("path");
var Sequelize = require("sequelize");
var logger = require('winston');
var configHelper = require('../helpers/config-helper');
var basename  = path.basename(module.filename);
var config    = configHelper.getConfig();
var sequelize = new Sequelize(config.database, config.username, config.password, config);
var db = {};

fs
    .readdirSync(__dirname)
    .filter(function(file) {
        return (file.indexOf(".") !== 0) && (file !== basename);
    })
    .forEach(function(file) {
        var model = sequelize["import"](path.join(__dirname, file));
        db[model.name] = model;
    });

Object.keys(db).forEach(function(modelName) {
    if ("associate" in db[modelName]) {
        db[modelName].associate(db);
    }
});
db.Group.hasMany(db.User, {
    foreignKey: 'groupId',
    as: 'User'
})

db.User.belongsTo(db.Group, {
    foreignKey: 'groupId',
    as: 'Group'
})
db.sequelize = sequelize;
db.Sequelize = Sequelize;

module.exports = db;
