"use strict";

module.exports = function (sequelize, DataTypes){
    var Status=sequelize.define("Status",{
        statusId: {
            type: DataTypes.INTEGER(5),
            autoIncrement:true,
            primaryKey:true
        },
        statusInfo: {
            type: DataTypes.STRING(100),
            allowNull:false
        }
    }, 
    {
        tableName:'Status',
        timestamps:false
    });
    return Status;
}