"use strict";
module.exports=function(sequelize, DataTypes){

    var Meeting=sequelize.define('Meeting', {
    meetingId:{
        type: DataTypes.INTEGER(5),
        autoIncrement: true,
        primaryKey: true
    },
    meetingName:{
        type: DataTypes.STRING(20),
        allowNull: false
    },
    meetingSummary:{
        type: DataTypes.STRING(),
        allowNull: false
    },
    meetingAgenda:{
        type: DataTypes.STRING(),
        allowNull: false
    },
    meetingDate:{
        type: DataTypes.DATE,
        allowNull: false
    },
    meetingTime:{
        type: DataTypes.STRING(20),
        allowNull: false
    },
    meetingStatus:{
        type: DataTypes.STRING(20),
        allowNull: false
    },
    groupId:{
        type: DataTypes.INTEGER(5),
        allowNull: false
    },
    meetingLocation:{
        type: DataTypes.STRING(20),
        allowNull: false
    },
    totalAttendees:{
        type: DataTypes.INTEGER(),
        allowNull: false
    },
    attendees:{
        type: DataTypes.TEXT('long'),
        allowNull: false
    },

},
        {
            tableName: 'Meeting',
            timestamps: false
        }
        );
    return Meeting;
}

