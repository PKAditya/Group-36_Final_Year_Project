"use strict";
module.exports = function(sequelize, DataTypes){
    var Group=sequelize.define("Group",{
            groupId:{
                type: DataTypes.INTEGER(5),
                autoIncrement: true,
                primaryKey: true
            },
            groupName:{
                type: DataTypes.STRING(20),
                allowNull: false
            },
            dof:{
                type: DataTypes.DATE,
                allowNull: false
            },
            houseNo:{
                type: DataTypes.INTEGER(5),
                allowNull: false
            },
            currentSecretary:{
                type: DataTypes.INTEGER(5),
                allowNull: false
            },
            currentPresedent:{
                type: DataTypes.INTEGER(5),
                allowNull: false
            },
            currentTresurer:{
                type: DataTypes.INTEGER(5),
                allowNull: false
            },
            town:{
                type: DataTypes.STRING(20),
                allowNull: false
            },
            district:{
                type: DataTypes.STRING(20),
                allowNull: false
            },
            pinCode:{
                type: DataTypes.STRING(6),
                allowNull: false
            },
            totalMembers:{
                type: DataTypes.INTEGER(5),
                allowNull: false
            },
            statusId:{
                type: DataTypes.INTEGER(5),
                allowNull: false
            },
            clusterId:{
                type:DataTypes.INTEGER(5),
                allowNull:false
            },
            bank_account_creation_date:{
                type: DataTypes.DATE,
                allowNull: false
            },
            bank_account_num:{
                type: DataTypes.STRING,
                allowNull: false
            },
            bank_branch_id:{
                type: DataTypes.INTEGER(5),
                allowNull:false
            },
            doc:{
                type: DataTypes.DATE,
                allowNull: false
            },
            sg_RegNo:{
                type: DataTypes.STRING(20),
                allowNull: false
            },
            old_RegNo:{
                type: DataTypes.STRING(20),
                allowNull: false
            },
            panchayat:{
                type: DataTypes.STRING(20),
                allowNull: false
            }

        },
        {
            tableName: 'Group',
            timestamps: false
        });
    return Group;
}