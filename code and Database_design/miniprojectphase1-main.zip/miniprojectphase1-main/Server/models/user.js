"use strict";
module.exports = function(sequelize, DataTypes){
    var User=sequelize.define("User",{
        userId:{
            type: DataTypes.INTEGER(5),
            autoIncrement: true,
            primaryKey: true
        },
        firstname:{
            type: DataTypes.STRING(20),
            allowNull: false
        },
        lastname:{
            type: DataTypes.STRING(20),
            allowNull: false
        },
        username:{
            type: DataTypes.STRING(20),
            allowNull: false
        },
        password:{
            type: DataTypes.STRING(128),
            allowNull: false
        },
        dob:{
            type: DataTypes.DATE,
            allowNull: false
        },
        houseNo:{
            type: DataTypes.STRING(20),
            allowNull: false
        },
        streetName:{
            type: DataTypes.STRING(20),
            allowNull: false
        },
        town:{
            type: DataTypes.STRING(20),
            allowNull: false
        },
        district:{
            type: DataTypes.STRING(20),
            allowNull: false
        },
        pinCode:{
            type: DataTypes.STRING(6),
            allowNull: false
        },
        phoneNumber:{
            type: DataTypes.STRING(11),
            unique: true,
            allowNull: false
        },
        statusId:{
            type: DataTypes.INTEGER(5),
            allowNull: false
        },
        groupId:{
            type: DataTypes.INTEGER(5),
            allowNull: false
        },
        role:{
            type: DataTypes.STRING(20),
            allowNull: false

        }
    },
    {
      tableName: 'User',
      timestamps: false
    });
    return User;
}