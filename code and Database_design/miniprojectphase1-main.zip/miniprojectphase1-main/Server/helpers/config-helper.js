"use strict";
var logger = require('./logger-helper').logger;
var config = require('../config/config.json');
var env  = process.env.NODE_ENV || "development";

var ConfigHelper = {
    envConfig:config[env],
    getConfig:function(){
        return this.envConfig;
    }
};

module.exports = ConfigHelper;