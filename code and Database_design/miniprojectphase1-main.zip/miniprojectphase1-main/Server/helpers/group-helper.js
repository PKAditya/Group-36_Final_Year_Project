"use strict";

// var logger = require('./logger-helper').logger;
var models = require('../models');
var statusHelper = require('./status-helper');
const {logger} = require("./logger-helper");

// var crypto = require('crypto');

var GroupHelper = {
    cacheLoaded: false,
    groups: [],
    groupNamesMap: {},

    updateCache: async function () {
        var groupHelper = this;
        if (statusHelper.cacheLoaded) {
            logger.info("User helper: Cache start");
            var userCache = await this.findAllCache();
            if (userCache) {
                userCache.forEach(function (user) {
                    groupHelper.addToCache(user);
                    logger.info("User :"+user.username+", StatusID:"+user.statusId);
                })
                groupHelper.cacheLoaded = true;
                logger.info("User helper: Cache populated");
            }
        }
        else {
            setTimeout(function () {
                groupHelper.updateCache();
            }, 1000);
        }
    },
    login: function (username, password) {
        return models.User.findOne({
            where: { username: username, password: password,role:'Admin', statusId: statusHelper.statusMap['Active'].statusId }, attributes: {
            }
        });
    },
    addToCache: function (group) {
        group = JSON.parse(JSON.stringify(group));

        this.groups.push(group);
        this.groupNamesMap[group.groupName] = group;
    },

    updateToCache: function (group) {
        this.removeFromCache(group);
        this.addToCache(group);
    },

    removeFromCache: function (group) {
        for (var i = 0; i < this.groups.length; i++) {
            if (this.groups[i].groupName === group.groupName) {
                delete this.groupNamesMap[this.groups[i].groupName];
                this.groups.splice(i, 1);
                break;
            }
        }
    },

    findAllCache: function () {
        return models.Group.findAll(
            {
                where: { statusId: statusHelper.statusMap['Active'].statusId },
                // attributes: { exclude: ['password'] }
            }
        );
    },
    findAllUsers:async function(groupId){
        return models.Group.findOne({
            include: [{
                model: models.User,
                as: 'User'
            }],
            where: { groupId: groupId, statusId: statusHelper.statusMap['Active'].statusId }
        });
    },
    findById: async function (groupId) {
        return models.Group.findOne({ where: { groupId: groupId, statusId: statusHelper.statusMap['Active'].statusId },  });
    },

    findByGroupNameUIMap: function (groupName) {
        return this.groupNamesMap[groupName];
    },

    findBygroupName: function (groupName) {
        return models.Group.findOne({ where: { groupName: groupName, statusId: statusHelper.statusMap['Active'].statusId },  });
    },

    create: async function (groupToCreate){
        var createdGroup = await models.Group.create(groupToCreate);
        this.addToCache(createdGroup);
        return createdGroup;
    },



    update: async function(groupToUpdate,requester){
        console.log("Updating details");
        var groupHelper = this;
        var group = await groupHelper.findBygroupName(groupToUpdate.groupName);
        console.log(group.groupName);
        if (group){
            if(groupToUpdate.groupId === requester.groupId){
                group.groupName=groupToUpdate.groupName;
                group.dof=groupToUpdate.dof;
                group.houseNo=groupToUpdate.houseNo;
                group.streetName=groupToUpdate.streetName;
                group.currentPresedent=groupToUpdate.currentPresedent;
                group.currentSecretary=groupToUpdate.currentSecretary;
                group.currentTresurer=groupToUpdate.currentTresurer;
                group.town=groupToUpdate.town;
                group.district=groupToUpdate.district;
                group.pinCode=groupToUpdate.pinCode;
                group.phoneNumber=groupToUpdate.phoneNumber;
                group.totalMembers=groupToUpdate.totalMembers;
                group.statusId=groupToUpdate.statusId;
                var updatedGroup = group.save();
                this.updateToCache(updatedGroup);
                return updatedGroup;
            }
        }
    },
    //
    // updatePassword: function (groupToUpdate, updaterId) {
    //     if (groupToUpdate.groupName!==updaterId.groupName) {
    //         throw "Unauthorized request";
    //     } else {
    //         var groupHelper = this;
    //         return groupHelper.findBygroupName(groupToUpdate.groupName).then(function (group) {
    //             group.password = groupToUpdate.password;
    //             return group.save();
    //         });
    //     }
    // },

    // getHash: function (password) {
    //     var hash = crypto.createHash('sha512');
    //     hash.update(password);
    //     return hash.digest('hex');
    // },

    deleteByGroupName: async function(groupName,requester){
        var groupHelper = this;
        var group = await this.findBygroupName(groupName);
        if(group){
            if(group.groupName!==requester.groupName){
                throw "Unauthorized request";
            }
            else{
                return groupHelper.deleteGroup(group);
            }
        }
    },

    deleteGroup:function(group){
        group.groupName = group.groupName+"_DELETED_";
        return group.save();
    },
};
GroupHelper.updateCache();
module.exports = GroupHelper;
