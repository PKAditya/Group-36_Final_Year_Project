"use strict";

var logger = require('./logger-helper').logger;
var models = require('../models');
var statusHelper = require('./status-helper');
var crypto = require('crypto');

var UserHelper = {
    cacheLoaded: false,
    users: [],
    userNamesMap: {},
    updateCache: async function () {
        var userHelper = this;
        if (statusHelper.cacheLoaded) {
            logger.info("User helper: Cache start");
            var userCache = await this.findAllCache();
            if (userCache) {
                userCache.forEach(function (user) {
                    userHelper.addToCache(user);
                    logger.info("User :"+user.username+", StatusID:"+user.statusId);
                })
                userHelper.cacheLoaded = true;
                logger.info("User helper: Cache populated");
            }
        }
        else {
            setTimeout(function () {
                userHelper.updateCache();
            }, 1000);
        }
    },

    addToCache: function (user) {
        user = JSON.parse(JSON.stringify(user));

        this.users.push(user);
        this.userNamesMap[user.username] = user;
    },

    updateToCache: function (user) {
        this.removeFromCache(user);
        this.addToCache(user);
    },

    removeFromCache: function (user) {
        for (var i = 0; i < this.users.length; i++) {
            if (this.users[i].username === user.username) {
                delete this.userNamesMap[this.users[i].username];
                this.users.splice(i, 1);
                break;
            }
        }
    },

    findAllCache: function () {
        return models.User.findAll(
            {
                where: { statusId: statusHelper.statusMap['Active'].statusId },
                attributes: { exclude: ['password'] }
            }
        );
    },

    login: function (username, password) {
        return models.User.findOne({
            where: { username: username, password: password, statusId: statusHelper.statusMap['Active'].statusId }, attributes: {
            }
        });
    },

    findByUsernameUIMap: function (username) {
        return this.userNamesMap[username];
    },
    findByIdUIMap: function (id) {
        return models.User.findOne({ where: { userId: id, statusId: statusHelper.statusMap['Active'].statusId }, attributes: { exclude: ['password', 'passwordHint'] } });
    },

    findByUsername: function (username) {
        return models.User.findOne({ where: { username: username, statusId: statusHelper.statusMap['Active'].statusId }, attributes: { exclude: ['password', 'passwordHint'] } });
    },

    create: async function (userToCreate){
        userToCreate.statusId = statusHelper.statusMap['Active'].statusId;
        var createdUser = await models.User.create(userToCreate);
        this.addToCache(createdUser);
        return createdUser;
    },

    selfCreate: async function (userToCreate) {
        if (userToCreate) {
            userToCreate.statusId = statusHelper.statusMap['Active'].statusId;
            var createdUser = await models.User.create(userToCreate);
            this.addToCache(createdUser);
            return createdUser;
        } else
            throw "no Data Found";
    },

    update: async function(userToUpdate,requester){
        console.log("Updating details");
        var userHelper = this;
        var user = await userHelper.findByUsername(userToUpdate.username);
        console.log(user.username);
        if (user){
            if(userToUpdate.username === requester.username){
                user.firstname=userToUpdate.firstname;
                user.lastname=userToUpdate.lastname;
                user.dob=userToUpdate.dob;
                user.houseNo=userToUpdate.houseNo;
                user.streetName=userToUpdate.streetName;
                user.town=userToUpdate.town;
                user.district=userToUpdate.district;
                user.pinCode=userToUpdate.pinCode;
                user.phoneNumber=userToUpdate.phoneNumber;
                var updatedUser = user.save();
                this.updateToCache(updatedUser);
                return updatedUser;
            }
        }
    },

    updatePassword: function (userToUpdate, updaterId) {
        if (userToUpdate.username!==updaterId.username) {
            throw "Unauthorized request";
        } else {
            var userHelper = this;
            return userHelper.findByUsername(userToUpdate.username).then(function (user) {
                user.password = userToUpdate.password;
               return user.save();
            });
        }
    },

    getHash: function (password) {
        var hash = crypto.createHash('sha512');
        hash.update(password);
        return hash.digest('hex');
    },

    deleteByUsername: async function(username,requester){
        var userHelper = this;
        var user = await this.findByUsername(username);
        if(user){
            if(user.username!==requester.username){
                throw "Unauthorized request";
            }
            else{
                return userHelper.deleteUser(user);
            }
        }
    },

    deleteUser:function(user){
        user.statusId = statusHelper.statusMap['Active'].statusId;
        user.username = user.username+"_DELETED_";
        return user.save();
    },
};
UserHelper.updateCache();
module.exports = UserHelper;
