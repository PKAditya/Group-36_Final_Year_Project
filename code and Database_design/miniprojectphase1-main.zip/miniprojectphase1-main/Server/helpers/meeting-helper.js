"use strict";

// var logger = require('./logger-helper').logger;
var models = require('../models');
// var statusHelper = require('./status-helper');
// var crypto = require('crypto');

var MeetingHelper = {
    cacheLoaded: false,
    Meeting: [],
    meetingNamesMap: {},


    // updateCache: async function () {
    //     var meetingHelper = this;
    //     if (statusHelper.cacheLoaded) {
    //         logger.info("meeting helper: Cache start");
    //         var meetingCache = await this.findAllCache();
    //         if (meetingCache) {
    //             meetingCache.forEach(function (meeting) {
    //                 meetingHelper.addToCache(meeting);
    //                 logger.info("meeting :"+meeting.meetingname+", StatusID:"+meeting.statusId);
    //             })
    //             meetingHelper.cacheLoaded = true;
    //             logger.info("meeting helper: Cache populated");
    //         }
    //     }
    //     else {
    //         setTimeout(function () {
    //             meetingHelper.updateCache();
    //         }, 1000);
    //     }
    // },
    //
    addToCache: function (meeting) {
        meeting = JSON.parse(JSON.stringify(meeting));

        this.Meeting.push(meeting);
        this.meetingNamesMap[meeting.meetingName] = meeting;
    },
    //
    // updateToCache: function (meeting) {
    //     this.removeFromCache(meeting);
    //     this.addToCache(meeting);
    // },

    removeFromCache: function (meeting) {
        for (var i = 0; i < this.Meeting.length; i++) {
            if (this.Meeting[i].meetingName === meeting.meetingName) {
                delete this.meetingNamesMap[this.Meeting[i].meetingName];
                this.Meeting.splice(i, 1);
                break;
            }
        }
    },

    findAllCache: function () {
        return models.Meeting.findAll(
            {
                // where: {groupId: groupId}
            }
        );
    },



    findBymeetingname: function (meetingname) {
        return models.Meeting.findOne({ where: { meetingName: meetingname }});
    },

    create: async function (meetingToCreate){
        // meetingToCreate.statusId = statusHelper.statusMap['Active'].statusId;
        var createdmeeting = await models.Meeting.create(meetingToCreate);
        this.addToCache(createdmeeting);
        return createdmeeting;
    },

    // selfCreate: async function (meetingToCreate) {
    //     if (meetingToCreate) {
    //         // meetingToCreate.statusId = statusHelper.statusMap['Active'].statusId;
    //         var createdmeeting = await models.Meeting.create(meetingToCreate);
    //         this.addToCache(createdmeeting);
    //         return createdmeeting;
    //     } else
    //         throw "no Data Found";
    // },

    // update: async function(meetingToUpdate,requester){
    //     console.log("Updating details");
    //     var meetingHelper = this;
    //     var meeting = await meetingHelper.findBymeetingname(meetingToUpdate.meetingname);
    //     console.log(meeting.meetingname);
    //     if (meeting){
    //         if(meetingToUpdate.meetingname === requester.meetingname){
    //             meeting.firstname=meetingToUpdate.firstname;
    //             meeting.lastname=meetingToUpdate.lastname;
    //             meeting.dob=meetingToUpdate.dob;
    //             meeting.houseNo=meetingToUpdate.houseNo;
    //             meeting.streetName=meetingToUpdate.streetName;
    //             meeting.town=meetingToUpdate.town;
    //             meeting.district=meetingToUpdate.district;
    //             meeting.pinCode=meetingToUpdate.pinCode;
    //             meeting.phoneNumber=meetingToUpdate.phoneNumber;
    //             var updatedmeeting = meeting.save();
    //             this.updateToCache(updatedmeeting);
    //             return updatedmeeting;
    //         }
    //     }
    // },

    // updatePassword: function (meetingToUpdate, updaterId) {
    //     if (meetingToUpdate.meetingname!==updaterId.meetingname) {
    //         throw "Unauthorized request";
    //     } else {
    //         var meetingHelper = this;
    //         return meetingHelper.findBymeetingname(meetingToUpdate.meetingname).then(function (meeting) {
    //             meeting.password = meetingToUpdate.password;
    //             return meeting.save();
    //         });
    //     }
    // },

    // getHash: function (password) {
    //     var hash = crypto.createHash('sha512');
    //     hash.update(password);
    //     return hash.digest('hex');
    // },

    deleteBymeetingname: async function(meetingname,requester){
        var meetingHelper = this;
        var meeting = await this.findBymeetingname(meetingname);
        if(meeting){
            if(meeting.meetingName!==requester.meetingName){
                throw "Unauthorized request";
            }
            else{
                return meetingHelper.deletemeeting(meeting);
            }
        }
    },

    deletemeeting:function(meeting){
        meeting.meetingName = meeting.meetingName+"_DELETED_";
        return meeting.save();
    },
};
// MeetingHelper.updateCache();
module.exports = MeetingHelper;
