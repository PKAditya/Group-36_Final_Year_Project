"use strict";

var logger = require('./logger-helper').logger;
var models = require('../models');

var StatusHelper = {
    cacheLoaded:false,
    statusarr: [],
    statusMap : {},
    updateCache: async function(){
        logger.info("Status helper: Cache start");
        var statusHelper = this;

        var statusCache = await this.findAllCache();
        if(statusCache){
            statusCache.forEach(function(status){
                statusHelper.addToCache(status);
                logger.info("Status :"+status.statusInfo+", ID:"+status.statusId);
            });
            logger.info("statusHelper.cacheLoaded = true");
            statusHelper.cacheLoaded = true;
        }
    },

    addToCache: function(status){
        status = JSON.parse(JSON.stringify(status));
        this.statusarr.push(status);
        this.statusMap[status.statusInfo]= status;
    },

    updateToCache:function(status){
        this.removeFromCache(status);
        this.addToCache(status);
    },

    removeFromCache:function(statusId){
        for(var i=0;i<this.statusarr.length;i++){
            if(this.statusarr[i].statusId === statusId){
                delete this.statusMap[status];
                this.statuses.splice(i,1);
                break;
            }
        }
    },

    findAll:function(){
        var statuses = [];
        StatusHelper.copyArray(this.statusarr,statuses);
        return new statusCache(function(resolve,reject){
            resolve(statuses);
        });
    },

    findAllCache:function(){
        return models.Status.findAll({order:[['statusInfo','ASC']]});
    },

    findByUsername:function(username){
        return models.Status.findByUsername(username);
    },

    deleteByUsername:function(username){
        logger.info('username of the status to be deleted %d',username);
        return this.findByUsername(username).then(function(status){
            return status.destroy();
        })
    },

    copyArray:function(fromArray,toArray){
        fromArray.forEach(function(obj){
            toArray.push(obj);
        })
    },

    create:function(name){
        var status = {};
        status.statusInfo=name;
        return models.Status.create(status);
    },

    update:function(statusToUpdate){
        return this.findByUsername(statusToUpdate.statusId).then(function(status){
            status.statusInfo = statusToUpdate.status;
            return status.save();
        });
    }
};

StatusHelper.updateCache();

module.exports = StatusHelper;