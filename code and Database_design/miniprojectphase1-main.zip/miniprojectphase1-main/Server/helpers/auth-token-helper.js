"use strict";

var logger = require('./logger-helper').logger;
var crypto = require('crypto');
var salt = "AmmA"

var AuthToken = {
    tokens:{},
    allowed:[],
    getUserFromAuthToken:function(token){
        return this.tokens[token];
    },
    addToken:function (user){
        var token = this.getToken();
        this.tokens[token]=user;
        return token;
    },
    removeToken:function (token){
        delete this.tokens[token]
    },
    getToken:function(){
        var hash = crypto.createHash('sha1');
        var time = (new Date()).getTime();
        var rand = Math.random();
        hash.update(time+rand+salt);
        return hash.digest('hex');
    },
    isAllowedFunctionality:function(req,auth){
        var result = {};
        result.matched=false;
        result.unAuthentication = false;
        var user = this.getUserFromAuthToken(auth)
        for(var i=0;i<this.allowed.length;i++){
            if(this.allowed[i].method === req.method && (new RegExp(this.allowed[i].path).test(req.path) || new RegExp(this.allowed[i].path).test(req.baseUrl))){
                var allowedRoles = this.allowed[i].allowedRoles;
                console.log(allowedRoles);
                if(allowedRoles.length === 1 && allowedRoles[0] === "NoLogin"){
                    result.matched = true;
                    break;
                }
                else{
                    if(user){
                        if(allowedRoles.length === 1 && allowedRoles[0] === "*" ){
                            result.matched = true;
                            break;
                        }
                    }
                    else{
                        result.unAuthentication = true;
                    }
                }
                break;
            }
        }
        return result;
    }
};

AuthToken.allowed.push({"method":"GET","path":'/assets',allowedRoles:['*']});
AuthToken.allowed.push({"method":"GET","path":'/status',allowedRoles:['*']});
AuthToken.allowed.push({"method":"GET","path":'/user',allowedRoles:['*']});//get user details
AuthToken.allowed.push({"method":"PUT","path":'/user',allowedRoles:['*']});//update user details
AuthToken.allowed.push({"method":"POST","path":'/user/login',allowedRoles:['NoLogin']});
AuthToken.allowed.push({"method":"POST","path":'/group/login',allowedRoles:['NoLogin']});
AuthToken.allowed.push({"method":"GET","path":'/group',allowedRoles:['NoLogin']});
AuthToken.allowed.push({"method":"GET","path":'/group/all',allowedRoles:['NoLogin']});
AuthToken.allowed.push({"method":"POST","path":'/group/create',allowedRoles:['*']});
AuthToken.allowed.push({"method":"PUT","path":'/group/update',allowedRoles:['*']});
AuthToken.allowed.push({"method":"POST","path":'/user/self-registration',allowedRoles:['NoLogin']});
AuthToken.allowed.push({"method":"POST","path":'/user/update-password',allowedRoles:['*']});
// AuthToken.allowed.push({"method":"GET","path":'/meeting',allowedRoles:['*']});
// AuthToken.allowed.push({"method":"GET","path":'/meeting/all',allowedRoles:['*']});
// AuthToken.allowed.push({"method":"GET","path":'/meeting/create',allowedRoles:['*']});
AuthToken.allowed.push({"method":"POST","path":'/user/logout',allowedRoles:['*']});
AuthToken.allowed.push({"method":"POST","path":'/user',allowedRoles:['*']});
AuthToken.allowed.push({"method":"POST","path":'/user/update-password',allowedRoles:['*']});


module.exports = AuthToken;