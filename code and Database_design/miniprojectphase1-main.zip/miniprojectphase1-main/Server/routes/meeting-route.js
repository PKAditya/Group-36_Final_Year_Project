var express = require('express');
var meeting = express.Router();
var meetingHelper = require('../helpers/meeting-helper');
var responder = require('../responder');
// var authTokenHelper = require('../helpers/auth-token-helper');
// var logger = require('../helpers/logger-helper').logger;
// var util = require('./util');


// meeting.post('/create', async function(req, res, next) {
//     var meetingJson = req.body;
//     try{
//         let meetingCreated = await meetingHelper.selfCreate(meetingJson);
//         if(meetingCreated){
//             responder.respond(res,meetingCreated,responder.SUCCESS,"meetings created successfully");
//         }
//         else{
//             responder.respond(res,null,responder.FAILED,"meeting creation failed");
//         }
//     }catch(fault){
//         logger.error("meetings creation failed. Reason:",fault);
//         responder.respond(res,null,responder.FAILED,"meetings creation failed. Reason:"+fault);
//     }
// });

// meeting.post('/', async function(req, res, next) {
//     var meetingJson = req.body;
//     var requester = util.getmeeting(req);
//     try{
//         let meetingCreated = await meetingHelper.create(meetingJson,requester);
//         if(meetingCreated){
//             var token = authTokenHelper.addToken(meeting);
//             responder.respond(res,meetingCreated,responder.SUCCESS,"meetings created successfully");
//         }
//         else{
//             responder.respond(res,null,responder.FAILED,"meeting creation failed");
//         }
//     }catch(fault){
//         logger.error("meetings creation failed. Reason:",fault);
//         responder.respond(res,null,responder.FAILED,"meetings creation failed. Reason:"+fault);
//     }
// });
//
//
// meeting.get('/:meetingname', function(req, res, next) {
//     var meetingname = parseInt(req.params.id);
//     //var meetingName = req.query.meetingName;
//     let meetingModel = meetingHelper.findBymeetingnameUIMap(meetingname);
//     var requester = util.getmeeting(req);
//     try{
//         responder.respond(res,meetingModel,responder.SUCCESS,"meeting retrieved successfully");
//     }catch(fault){
//         logger.error("meeting query failed. Reason: Un authorized request");
//         responder.respondUnAuthorization(res);
//     }
// });
//
// meeting.put('/:meetingname', async function(req, res, next) {
//     var meetingJson = req.body;
//     console.log(meetingJson);
//     var meeting = util.getmeeting(req);
//     console.log(meeting);
//     try{
//         let meetingUpdated = await meetingHelper.update(meetingJson, meeting);
//         if(meetingUpdated){
//             responder.respond(res,meetingUpdated,responder.SUCCESS,"meeting updated successfully");
//
//         }
//         else{
//             responder.respond(res,null,responder.FAILED,"meeting update failed");
//         }
//         //}
//     }catch(fault){
//         logger.error("meetings update failed. Reason:",fault);
//         responder.respond(res,null,responder.FAILED,"meeting update failed. Reason:"+fault);
//     }
// });
//
// meeting.post('/login', async function(req,res,next){
//     var credJson = req.body;
//     try{
//         let meeting = await meetingHelper.login(credJson.meetingname,credJson.password);
//         if(meeting){
//             var token = authTokenHelper.addToken(meeting);
//             console.log(token+" logged in meeting");
//             responder.respond(res,meeting,responder.SUCCESS,"Login success",token);
//         }
//         else{
//             responder.respond(res,null,responder.FAILED,"Login failed. Please check your meeting name and password.");
//         }
//     }
//     catch(fault){
//         logger.error("Login failed. Reason:",fault);
//         responder.respond(res,null,responder.FAILED,"Login failed. Reason:"+fault);
//     }
//
// });
//
// meeting.post('/update-password', async function(req,res,next){
//         var meetingJson = req.body;
//         var meeting = util.getmeeting(req);
//         try{
//             let meetingUpdated = await meetingHelper.updatePassword(meetingJson, meeting.meetingId);
//             if(meetingUpdated){
//                 meetingHelper.updateToCache(meeting);
//                 responder.respond(res,meeting,responder.SUCCESS,"Password update success");
//             }
//             else{
//                 responder.respond(res,null,responder.FAILED,"Password update failed");
//             }
//         }
//         catch(fault){
//             logger.error("Password update failed. Reason:",fault);
//             responder.respond(res,null,responder.FAILED,"Password update failed. Reason:"+fault);
//         }
//     },
//
//     meeting.post('/logout', async function(req,res,next){
//         var auth = req.query.authToken;
//         if(auth){
//             authTokenHelper.removeToken(auth);
//             responder.respond(res,null,responder.SUCCESS,"Logout success",auth);
//         }
//         else{
//             responder.respond(res,null,responder.FAILED,"Logout failed. Unauthorized");
//         }
//     }));
//
meeting.delete('/:id', async function(req, res, next) {
    var id = parseInt(req.params.id);
    // var requester = util.getmeeting(req);
    let meetingModel = meetingHelper.findBymeetingname(meetingname);
    try{
        var deletedmeeting = await meetingHelper.deleteBymeetingname(meetingname,requester);
        if(deletedmeeting){
            meetingHelper.removeFromCache(meetingModel);
            responder.respond(res,null,responder.SUCCESS,"meeting deletion success");
        }
    }
    catch(fault){
        responder.respond(res,null,responder.FAILED,"meeting deletion failed. Reason:"+fault);
    }
});



meeting.post('/create', async function(req, res, next) {
    var meetingJson = req.body;
    try{
        let meetingCreated = await meetingHelper.create(meetingJson);
        if(meetingCreated){
            responder.respond(res,meetingCreated,responder.SUCCESS,"meetings created successfully");
        }
        else{
            responder.respond(res,null,responder.FAILED,"meeting creation failed");
        }
    }catch(fault){
        logger.error("meetings creation failed. Reason:",fault);
        responder.respond(res,null,responder.FAILED,"meetings creation failed. Reason:"+fault);
    }
});

meeting.get('/:meetingname', async function(req, res, next) {
    var meetingname = req.query.meetingname;
    try{
        let meetingModel = await meetingHelper.findBymeetingname(meetingname);
        responder.respond(res,meetingModel,responder.SUCCESS,"meeting retrieved successfully");
    }catch(fault){
        logger.error("meeting query failed. Reason: Un authorized request");
        responder.respondUnAuthorization(res);
    }
});

meeting.get('/all', async function(req, res, next) {
    console.log("rajendra")
    try{
        let meetingModel = await meetingHelper.findAllCache();
        responder.respond(res,meetingModel,responder.SUCCESS,"meeting retrieved successfully");
    }catch(fault){
        logger.error("meeting query failed. Reason: Un authorized request");
        responder.respondUnAuthorization(res);
    }
});
module.exports = meeting;
