var express = require('express');
var user = express.Router();
var userHelper = require('../helpers/user-helper');
var responder = require('../responder');
var authTokenHelper = require('../helpers/auth-token-helper');
var logger = require('../helpers/logger-helper').logger;
var util = require('./util');


user.post('/self-registration', async function(req, res, next) {
    var userJson = req.body;
    try{
        let userCreated = await userHelper.selfCreate(userJson);
        if(userCreated){
            responder.respond(res,userCreated,responder.SUCCESS,"Users created successfully");
        }
        else{
            responder.respond(res,null,responder.FAILED,"User creation failed");
        }
    }catch(fault){
        logger.error("Users creation failed. Reason:",fault);
        responder.respond(res,null,responder.FAILED,"Users creation failed. Reason:"+fault);
    }
});

user.post('/', async function(req, res, next) {
    var userJson = req.body;
    var requester = util.getUser(req);
    try{
        let userCreated = await userHelper.create(userJson,requester);
        if(userCreated){
            var token = authTokenHelper.addToken(user);
            responder.respond(res,userCreated,responder.SUCCESS,"Users created successfully");
        }
        else{
            responder.respond(res,null,responder.FAILED,"User creation failed");
        }
    }catch(fault){
        logger.error("Users creation failed. Reason:",fault);
        responder.respond(res,null,responder.FAILED,"Users creation failed. Reason:"+fault);
    }
});


user.get('/:id', function(req, res, next) {
    var id = parseInt(req.params.id);
    //var userName = req.query.userName;
    let userModel = userHelper.findByIdUIMap(id);
    // var requester = util.getUser(req);
    try{
        responder.respond(res,userModel,responder.SUCCESS,"User retrieved successfully");
    }catch(fault){
        logger.error("User query failed. Reason: Un authorized request");
        responder.respondUnAuthorization(res);
    }
});

user.put('/:username', async function(req, res, next) {
    var userJson = req.body;
    console.log(userJson);
    var user = util.getUser(req);
    console.log(user);
    try{
        let userUpdated = await userHelper.update(userJson, user);
        if(userUpdated){
            responder.respond(res,userUpdated,responder.SUCCESS,"User updated successfully");

        }
        else{
            responder.respond(res,null,responder.FAILED,"User update failed");
        }
        //}
    }catch(fault){
        logger.error("Users update failed. Reason:",fault);
        responder.respond(res,null,responder.FAILED,"User update failed. Reason:"+fault);
    }
});

user.post('/login', async function(req,res,next){
    var credJson = req.body;
    try{
        let user = await userHelper.login(credJson.username,credJson.password);
        if(user){
            var token = authTokenHelper.addToken(user);
            console.log(token+" logged in user");
            responder.respond(res,user,responder.SUCCESS,"Login success",token);
        }
        else{
            responder.respond(res,null,responder.FAILED,"Login failed. Please check your user name and password.");
        }
    }
    catch(fault){
        logger.error("Login failed. Reason:",fault);
        responder.respond(res,null,responder.FAILED,"Login failed. Reason:"+fault);
    }

});

user.post('/update-password', async function(req,res,next){
        var userJson = req.body;
        var user = util.getUser(req);
        try{
            let userUpdated = await userHelper.updatePassword(userJson, user.userId);
            if(userUpdated){
                userHelper.updateToCache(user);
                responder.respond(res,user,responder.SUCCESS,"Password update success");
            }
            else{
                responder.respond(res,null,responder.FAILED,"Password update failed");
            }
        }
        catch(fault){
            logger.error("Password update failed. Reason:",fault);
            responder.respond(res,null,responder.FAILED,"Password update failed. Reason:"+fault);
        }
    },

    user.post('/logout', async function(req,res,next){
        var auth = req.query.authToken;
        if(auth){
            authTokenHelper.removeToken(auth);
            responder.respond(res,null,responder.SUCCESS,"Logout success",auth);
        }
        else{
            responder.respond(res,null,responder.FAILED,"Logout failed. Unauthorized");
        }
    }));

user.delete('/:id', async function(req, res, next) {
    var id = parseInt(req.params.id);
    var requester = util.getUser(req);
    let userModel = userHelper.findByUsernameUIMap(username);
    try{
        var deletedUser = await userHelper.deleteByUsername(username,requester);
        if(deletedUser){
            userHelper.removeFromCache(userModel);
            responder.respond(res,null,responder.SUCCESS,"User deletion success");
        }
    }
    catch(fault){
        responder.respond(res,null,responder.FAILED,"User deletion failed. Reason:"+fault);
    }
});

module.exports = user;
