
"use strict";

var authTokenHelper = require('../helpers/auth-token-helper');

var Util = {
    getUser:function(req){
        var auth = req.query.authToken;
        var user = authTokenHelper.getUserFromAuthToken(auth);
        return user;
    },
    getUsername:function (req) {
        var user = this.getUser(req);
        if(user){
            return user.username;
        }
        return null;
    }
};

module.exports = Util;