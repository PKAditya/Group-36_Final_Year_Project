var express = require('express');
var group = express.Router();
var groupHelper = require('../helpers/group-helper');
var responder = require('../responder');
var authTokenHelper = require('../helpers/auth-token-helper');
var logger = require('../helpers/logger-helper').logger;
var util = require('./util');


group.get('/', async function(req, res, next) {
    // var groupJson = req.body;
    var requester = util.getUser(req);
    try{
        // let groupCreated = await groupHelper.create(groupJson,requester);
        let groupId = requester.groupId;
        let group = await groupHelper.findById(groupId);
        if(group){
            // var token = authTokenHelper.addToken(group);
            responder.respond(res,group,responder.SUCCESS,"groups fetched successfully");
        }
        else{
            responder.respond(res,null,responder.FAILED,"group fetching failed");
        }
    }catch(fault){
        logger.error("groups creation failed. Reason:",fault);
        responder.respond(res,null,responder.FAILED,"groups creation failed. Reason:"+fault);
    }
});

//
// group.get('/:groupname', function(req, res, next) {
//     var groupname = parseInt(req.params.id);
//     //var groupName = req.query.groupName;
//     let groupModel = groupHelper.findByGroupNameUIMap(groupname);
//     // var requester = util.getgroup(req);
//     try{
//         responder.respond(res,groupModel,responder.SUCCESS,"group retrieved successfully");
//     }catch(fault){
//         logger.error("group query failed. Reason: Un authorized request");
//         responder.respondUnAuthorization(res);
//     }
// });
group.get('/all', async function(req, res, next){
    var requester = util.getUser(req);
    try{
        // let groupCreated = await groupHelper.create(groupJson,requester);
        let groupId = requester.groupId;
        let raj = await groupHelper.findAllUsers(groupId);
        let list = raj.User;
        if(group){
            // var token = authTokenHelper.addToken(group);
            responder.respond(res,list,responder.SUCCESS,"groups fetched successfully");
        }
        else{
            responder.respond(res,null,responder.FAILED,"group fetching failed");
        }
    }catch(fault){
        logger.error("groups creation failed. Reason:",fault);
        responder.respond(res,null,responder.FAILED,"groups creation failed. Reason:"+fault);
    }
});

group.put('/:groupname', async function(req, res, next) {
    var groupJson = req.body;
    console.log(groupJson);
    // var group = util.getGroup(req);
    console.log(group);
    try{
        let groupUpdated = await groupHelper.update(groupJson, group);
        if(groupUpdated){
            responder.respond(res,groupUpdated,responder.SUCCESS,"group updated successfully");

        }
        else{
            responder.respond(res,null,responder.FAILED,"group update failed");
        }
        //}
    }catch(fault){
        logger.error("groups update failed. Reason:",fault);
        responder.respond(res,null,responder.FAILED,"group update failed. Reason:"+fault);
    }
});

group.post('/login', async function(req,res,next){
    var credJson = req.body;
    try{
        let group = await groupHelper.login(credJson.username,credJson.password);
        if(group){
            var token = authTokenHelper.addToken(group);
            console.log(token+" logged in group");
            responder.respond(res,group,responder.SUCCESS,"Login success",token);
        }
        else{
            responder.respond(res,null,responder.FAILED,"Login failed. Please check your group name and password.");
        }
    }
    catch(fault){
        logger.error("Login failed. Reason:",fault);
        responder.respond(res,null,responder.FAILED,"Login failed. Reason:"+fault);
    }

});



group.delete('/:id', async function(req, res, next) {
    var id = parseInt(req.params.id);
    var requester = util.getUser(req);
    var group = groupHelper.findById(id);
    let groupModel = groupHelper.findByGroupNameUIMap(group.groupName);
    try{
        var deletedGroup = await groupHelper.deleteByGroupName(group.groupName,requester);
        if(deletedGroup){
            groupHelper.removeFromCache(groupModel);
            responder.respond(res,null,responder.SUCCESS,"group deletion success");
        }
    }
    catch(fault){
        responder.respond(res,null,responder.FAILED,"group deletion failed. Reason:"+fault);
    }
});

module.exports = group;
