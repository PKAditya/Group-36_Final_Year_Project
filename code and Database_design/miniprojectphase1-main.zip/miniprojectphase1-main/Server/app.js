var express = require('express');
var path = require('path');
var favicon = require('serve-favicon');
var loggerMorgan = require('morgan');
var winston = require('winston'),
    expressWinston = require('express-winston');
var cookieParser = require('cookie-parser');
var bodyParser = require('body-parser');
var loggerHelper = require('./helpers/logger-helper');
loggerHelper.init();
var logger = loggerHelper.logger;

logger.stream = {
    write: function(message, encoding) {
        logger.info(message);
    },
};

var authTokenHelper = require('./helpers/auth-token-helper');
var responder = require('./responder');
var moment = require('moment-timezone');
let configHelper = require('./helpers/config-helper');
var fs = require('fs');
var cors = require('cors');

var app = express();
if(configHelper.env === 'development'){
    app.use(cors());
}

function checkAuth(req,res,next){
    var auth = req.query.authToken;

    var result = authTokenHelper.isAllowedFunctionality(req,auth);
    if(result.matched){
        logger.info("Authorized request %s %s, from agent %s with authToken %s. Proceeding further.",req.path,req.method,req.headers['user-agent'],auth);
        next();
    }else if(result.unAuthentication){
        logger.info("Un authenticated request %s %s, from agent %s with authToken %s.",req.path,req.method,req.headers['user-agent'],auth);
        responder.respondUnAuthentication(res);
    }else{
        logger.info("Un authorized request %s %s, from agent %s with authToken %s.",req.path,req.method,req.headers['user-agent'],auth);
        responder.respondUnAuthorization(res);
    }
}
app.use(function(req, res, next) {
    logger.info('Routing Logs: %s,%s,%s,%s,%s,%s,%s,%s',req.url,req.path,req.protocol,req.baseUrl,req.hostname,req.ip,JSON.stringify(req.query),req.originalUrl);
    next();
});

app.use(express.static(configHelper.envConfig['public']));

app.use(configHelper.envConfig['event-images']+'/*',function (req,res,next){
    checkAuth(req,res,next);
});
app.use(configHelper.envConfig['profile-images']+'/*',function (req,res,next){
    checkAuth(req,res,next);
});
app.use(express.static(configHelper.envConfig['file-folder']));
app.use(bodyParser.json({limit: "50mb"}));
app.use(bodyParser.urlencoded({limit: "50mb", extended: true, parameterLimit:50000}));

var models = require('./models');

app.set('port',configHelper.envConfig['server_port'] || 8080);



Date.prototype.toJSON = function(){ return moment(this).format('YYYY-MM-DDTHH:mm:ss.SSSZ'); }

logger.info(JSON.stringify(process.versions));

process
    .on('unhandledRejection', (reason, p) => {
        console.log('Unhandled Rejection at Promise: Reason'+JSON.stringify(reason)+": p:"+p);
        logger.error(reason, 'Unhandled Rejection at Promise', p);
    })
    .on('uncaughtException', err => {
        console.log('Uncaught Exception thrown: Reason'+JSON.stringify(err));
        logger.error(err, 'Uncaught Exception thrown');
        // process.exit(1);
    });

models.sequelize.sync().then(() => {
    var server = app.listen(app.get('port'), () => {
        app.use(expressWinston.logger({
            transports: [
                new winston.transports.Console()
            ],
            format: winston.format.combine(
                winston.format.colorize(),
                winston.format.json()
            ),
            meta: true, // optional: control whether you want to log the meta data about the request (default to true)
            msg: "HTTP {{req.method}} {{req.url}}", // optional: customize the default logging message. E.g. "{{res.statusCode}} {{req.method}} {{res.responseTime}}ms {{req.url}}"
            expressFormat: true, // Use the default Express/morgan request formatting. Enabling this will override any msg if true. Will only output colors with colorize set to true
        }));
        app.use(bodyParser.json());
        app.use(bodyParser.urlencoded({ extended: true }));
        app.use(cookieParser());
        require("./helpers/status-helper");
        app.all("*",(req,res,next) => {
            res.setHeader('Access-Control-Allow-Origin', '*');
            res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
            res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
            res.setHeader('Access-Control-Allow-Credentials', true);
            checkAuth(req,res,next);
        });
        setTimeout(() => {
            var normalizedPath = require("path").join(__dirname,"routes");
            logger.info("normalizedPath %s",normalizedPath);

            fs.readdirSync(normalizedPath).forEach((file) => {
                if(file !== '.svn'){
                    var fileName = "./routes/"+file;
                    logger.info("fileName %s",fileName);
                    var route = require(fileName);
                    if(file.indexOf('-route.js') >= 0){
                        var routeName = "/"+file.substring(0,file.indexOf('-route.js'));
                        logger.info("routeName %s",routeName);
                        app.use(routeName,route);
                    }
                }
            });

            app.use((req, res, next) => {
                responder.respond(res,null, responder.NOT_FOUND,"Page not found");
            });

            logger.info('**** Setting up error traffic logs');
            app.use(function(err, req, res, next) {
                logger.info('Routing error: %s,%s',err.message,err.toString());
                responder.respond(res,err, responder.SERVER_ERROR,err.message);
            });

            var host = server.address().address;
            var port = server.address().port;
            logger.info('App is listening at http://%s:%s',host,port);

        },1000);

    });
});
module.exports = app;
