import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:swayam/screens/login/LogIn.dart';
import 'package:swayam/screens/shg/shg_management/shgManagement.dart';
import 'package:swayam/screens/shg/shgmembers.dart';



//importing dependencies

import 'package:form_field_validator/form_field_validator.dart';

class homescreen extends StatefulWidget {
  const homescreen({Key? key}) : super(key: key);

  @override
  State<homescreen> createState() => _homescreenState();
}

class _homescreenState extends State<homescreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //backgroundColor: Color(0xff1E1E1E),
      backgroundColor: Color(0xffFCFCFC),
      appBar: PreferredSize(
        child: AppBar(
          iconTheme: IconThemeData(color: Color(0xff6750A4)),
          actions: [Icon(Icons.account_circle,size: 30),Padding(padding: EdgeInsets.only(right: 20))],
          elevation: 0,

          centerTitle: true,
          title: Column(
            //mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.only(top: 10,bottom: 10),
                height: 90,
                child: Image.asset(
                  "assets/icons/swayam.jpg",
                ),
              )
            ],
          ),

          backgroundColor: Color(0xffFCFCFC),

        ),
        preferredSize: Size.fromHeight(70),
      ),
      drawer: const sideDrawer(),
      body: ListView(
        children: [
          Text("Total Members"),
          //user_reg(),
          // view_group(),
          // view_cluster(),
          // savings(),
          // loan_details(),

          Center(
            child: Text(
              'WORK IN PROGRESS......',
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }
}

class sideDrawer extends StatelessWidget {
  const sideDrawer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Container(
        color: Color(0xffc6b0ff),
        child: ListView(
          children: [
            Container(
                margin: EdgeInsets.symmetric(vertical: 25, horizontal: 30),
                child: Text(
                  "SHG OPTIONS",
                  style: TextStyle(
                    color: Colors.black54,
                    fontSize: 21,
                    fontFamily: "Montserrat",
                    //fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            Container(
              margin: EdgeInsets.symmetric(vertical: 25, horizontal: 30),
              child: Text(
                "My"
                    " SHG",
                style: TextStyle(
                  color: Colors.black54,
                  fontSize: 18,
                  fontFamily: "Montserrat-Bold",
                  //fontWeight: FontWeight.w600,
                ),
              ),
            ),
            ListTile(
              leading: Icon(Icons.group_work, color: Colors.black54, size: 17),
              title: Text(
                'SHG Management',
                style: TextStyle(
                  fontFamily: 'Prompt',
                  color: Colors.black54,
                  fontSize: 14,
                  // fontWeight: FontWeight.bold,
                ),
              ),
              onTap: () async {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => shgManagement(),
                    ));

              },
            ),
            ListTile(
              leading: Icon(Icons.groups, color: Colors.black54, size: 17),
              title: Text(
                'SHG Members',
                style: TextStyle(
                  fontFamily: 'Prompt',
                  color: Colors.black54,
                  fontSize: 14,
                  // fontWeight: FontWeight.bold,
                ),
              ),
              onTap: () async {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => shgmems(),
                    ));

              },
              // onTap: () async {
              //   await Future.delayed(Duration(seconds: 1));
              //   Navigator.pushAndRemoveUntil(
              //     context,
              //     MaterialPageRoute(
              //       builder: (context) => loginscreen(),
              //     ),
              //         (r) => false,
              //   );
              // },
            ),
            ListTile(
              leading: Icon(Icons.handshake, color: Colors.black54, size: 17),
              title: Text(
                'SHG Meetings',
                style: TextStyle(
                  fontFamily: 'Prompt',
                  color: Colors.black54,
                  fontSize: 14,
                  // fontWeight: FontWeight.bold,
                ),
              ),
              // onTap: () async {
              //   await Future.delayed(Duration(seconds: 1));
              //   Navigator.pushAndRemoveUntil(
              //     context,
              //     MaterialPageRoute(
              //       builder: (context) => loginscreen(),
              //     ),
              //         (r) => false,
              //   );
              // },
            ),
            ListTile(
              leading: Icon(Icons.currency_rupee_outlined, color: Colors.black54, size: 17),
              title: Text(
                'SHG Finances',
                style: TextStyle(
                  fontFamily: 'Prompt',
                  color: Colors.black54,
                  fontSize: 14,
                  // fontWeight: FontWeight.bold,
                ),
              ),
              // onTap: () async {
              //   await Future.delayed(Duration(seconds: 1));
              //   Navigator.pushAndRemoveUntil(
              //     context,
              //     MaterialPageRoute(
              //       builder: (context) => loginscreen(),
              //     ),
              //         (r) => false,
              //   );
              // },
            ),
            //------------------
            Container(margin: EdgeInsets.symmetric(horizontal: 50),child: SizedBox(
              width:150,
              height:39,
              child: Divider(thickness: 1.5,
                color: Color(0xff6750A4),

              ),
            ),),
            ListTile(
              leading: Icon(Icons.logout, color: Colors.black54, size: 17),
              title: Text(
                'LOG-OUT',
                style: TextStyle(
                  fontFamily: 'GoogleSans',
                  color: Colors.black54,
                  fontSize: 14,
                  // fontWeight: FontWeight.bold,
                ),
              ),
              onTap: () async {
                await Future.delayed(Duration(seconds: 1));
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(
                    builder: (context) => loginscreen(),
                  ),
                      (r) => false,
                );
              },
            ),

            //options title


             //log-out
          ],
        ),
      ),
    );
  }
} //options








//widgets used--------------------------------------------------------------------


//---------------------Widgets used
class user_reg extends StatelessWidget {
  const user_reg({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      child: InkWell(
        child: Container(
          margin: EdgeInsets.fromLTRB(30, 30, 30, 20),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(24),
              color: Color(0xff6750A4),
            // gradient: LinearGradient(
            //     begin: Alignment.centerLeft,
            //     end: Alignment.bottomRight,
            //     colors: [Color(0xfff2aa66),Color(0xffdf8e69)]),

            // colors: [Color(0xffd3a1e7), Color(0xff7d5dde)]),
          ),
          height: 100,
          width: double.infinity,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // Container(
              //   margin: EdgeInsets.only(bottom: 15),
              //   height: 70,
              //   width: 70,
              //   decoration: BoxDecoration(
              //     shape: BoxShape.circle,
              //     gradient: LinearGradient(
              //         begin: Alignment.topCenter,
              //         end: Alignment.bottomCenter,
              //         colors: [Colors.white38, Colors.white]),
              //   ),
              // ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset("assets/icons/add.png", height: 50, width: 50),
                  SizedBox(width: 20),
                  Center(
                    child: Text(
                      "USER REGISTRATION",
                      style: TextStyle(
                        color: Colors.white,
                        fontFamily: "Prompt",
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        shadows: [
                          Shadow(
                            offset: Offset(0.1, 0.1),
                            blurRadius: 5.0,
                            color: Colors.black,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        onTap: () async {
          // await Navigator.push(
          //   context,
          //   MaterialPageRoute(
          //     builder: (context) => ash_viewgroups(),
          //   ),
          // );
        },
      ),
    );
  }
}