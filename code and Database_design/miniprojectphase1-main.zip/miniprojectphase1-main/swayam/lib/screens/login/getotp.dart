import 'package:flutter/material.dart';
import 'package:swayam/screens/login/getotp.dart';
import '../homescreen/homescreen.dart';
import 'package:swayam/screens/login/LogIn.dart';

//importing dependencies
import 'package:form_field_validator/form_field_validator.dart';


class loginotp extends StatelessWidget {
  const loginotp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: PreferredSize(
        child: AppBar(
          iconTheme: IconThemeData(color: Color(0xff6750A4)),
          elevation: 0,
          centerTitle: true,
          leading: IconButton(onPressed: () {Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (context) => loginscreen(),
            ),
                (r) => false,
          );}, icon: Icon(Icons.arrow_back)),
          title: Column(
            //mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                padding: EdgeInsets.only(top: 10,bottom: 10),
                height: 90,
                child: Image.asset(
                  "assets/icons/swayam.jpg",
                ),
              )
            ],
          ),

          backgroundColor: Color(0xffFCFCFC),

        ),
        preferredSize: Size.fromHeight(70),
      ),
      resizeToAvoidBottomInset: true,
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,

      body: buildloginotp(),
    );

  }
}







//widgets used--------------------------------------------------------------------

class buildloginotp extends StatelessWidget {
  const buildloginotp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      width: double.infinity,
      height: size.height,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: AssetImage("assets/images/bg.png"),
          fit: BoxFit.cover,
          // colorFilter: ColorFilter.mode(
          //     Colors.black.withOpacity(0.6), BlendMode.dstATop),
        ),
      ),
      child: SingleChildScrollView(
        padding: EdgeInsetsDirectional.only(top: 60),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              child: Text(
                "LOG-IN",
                style: TextStyle(
                  fontSize: 25,
                  fontFamily: "Ubuntu",
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
              ),

            ),
            // Container(
            //   height: 180,
            //   width: 180,
            //   margin: EdgeInsetsDirectional.only(top: 70),
            //   child: Image.asset(
            //     "assets/images/amma_circ.png",
            //     height: size.height * 0.2,
            //   ),
            //   decoration: BoxDecoration(
            //       border: Border.all(width: 15, color: Color(0xffCCBBE7)),
            //       borderRadius: BorderRadius.circular(110)
            //   ),),
            Container(

              color: Color(0xffCCBBE7),
              margin: EdgeInsets.only(left: 25, right: 25,top:25,),
              child: Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 25, left: 15, right: 15),
                    child: Text(
                      'Please enter the OTP.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        decorationStyle: TextDecorationStyle.solid,
                        decorationThickness: 1.5,
                        color: Colors.black,
                        fontFamily: 'GoogleSans',
                        fontSize: 12,
                      ),
                    ),
                  ),
                  build_otp(),
                  Row(
                    children: [
                      Container(
                        padding: EdgeInsets.only(left: 55),
                        // child: forgotPass(),
                      )
                    ],
                  ),
                  build_loginbtn(),
                  SizedBox(height: 35,),
                ],
              ),
            ),
            // registerUser(),
          ],
        ),
      ),
    );
  }
}


Widget build_mobile() {
  return Container(
    margin: EdgeInsets.only(left: 45, right: 45),
    padding: EdgeInsets.only(top: 30),
    child: TextFormField(
      validator: MultiValidator([
        // RequiredValidator(errorText: "Field is required"),
        EmailValidator(errorText: "Enter a valid Phone Number"),
      ]),
      autovalidateMode: AutovalidateMode.always,
      keyboardType: TextInputType.phone,
      textInputAction: TextInputAction.next,
      cursorColor: Color(0xffCCBBE7),
      style: TextStyle(
        color: Colors.black54,
        fontSize: 14,
        fontFamily: 'Ubuntu',
        fontWeight: FontWeight.bold,
      ),
      //onSaved: (email) {},
      //controller: ,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(25)),
          borderSide: const BorderSide(color: Color(0xffCCBBE7)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(20)),
          borderSide: const BorderSide(color: Color(0xffCCBBE7)),
        ),
        //labelText: 'Type in your Username',
        labelStyle: TextStyle(
          color: Colors.black54,
          fontSize: 14,
          fontFamily: 'Prompt',
          fontWeight: FontWeight.bold,
        ),
        contentPadding: EdgeInsets.only(top: 14),
        prefixIcon: Icon(Icons.phone, color: Colors.black54),
        hintText: 'Phone Number',
        hintStyle: TextStyle(
          color: Colors.black54,
          fontSize: 14,
          fontFamily: 'Prompt',
          fontWeight: FontWeight.bold,
        ),
      ),
    ),
  );
}

Widget build_otp() {
  return Container(
    margin: EdgeInsets.only(left: 55, right: 55, top:15),
    child: TextFormField(
      validator: MultiValidator([
        // RequiredValidator(errorText: "Field is required"),
        EmailValidator(errorText: "Enter a valid OTP"),
      ]),
      autovalidateMode: AutovalidateMode.always,
      keyboardType: TextInputType.number,
      textInputAction: TextInputAction.next,
      cursorColor: Color(0xffCCBBE7),
      style: TextStyle(
        color: Colors.black54,
        fontSize: 14,
        fontFamily: 'Ubuntu',
        fontWeight: FontWeight.bold,
      ),
      //onSaved: (email) {},
      //controller: ,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(25)),
          borderSide: const BorderSide(color: Color(0xffCCBBE7)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(20)),
          borderSide: const BorderSide(color: Color(0xffCCBBE7)),
        ),
        //labelText: 'Type in your Username',
        labelStyle: TextStyle(
          color: Colors.black54,
          fontSize: 14,
          fontFamily: 'Poppins-Regular',
          fontWeight: FontWeight.bold,
        ),
        contentPadding: EdgeInsets.only(top: 14),
        prefixIcon: Icon(Icons.lock, color: Colors.black54),
        hintText: 'Type in your OTP',
        hintStyle: TextStyle(
          color: Colors.black54,
          fontSize: 14,
          fontFamily: 'Poppins-Regular',
          fontWeight: FontWeight.bold,
        ),
      ),
    ),
  );
}

class build_getotp extends StatelessWidget {
  const build_getotp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      child: InkWell(
        onTap: () async {
          await Future.delayed(
            Duration(seconds: 1),
          );
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (context) => loginotp(),
            ),
                (r) => false,
          );
          print('Getting OTP');
        },
        child: Container(
          margin: EdgeInsets.only(top:15),
          width: size.width * 0.32,
          height: 35,
          child: Center(
              child: Text(
                "GET OTP",
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: "GoogleSans",
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1),
              )),
          // margin: EdgeInsets.symmetric(horizontal: 100),
          // padding: EdgeInsets.symmetric(vertical: 20,),
          decoration: BoxDecoration(
              color: Color(0xff6750A4),
              borderRadius: BorderRadius.all(Radius.circular(25))),
        ),
      ),
    );
  }
}

class build_loginbtn extends StatelessWidget {
  const build_loginbtn({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      child: InkWell(
        onTap: () async {
          await Future.delayed(
            Duration(seconds: 1),
          );
          Navigator.pushAndRemoveUntil(
            context,
            MaterialPageRoute(
              builder: (context) => homescreen(),
            ),
                (r) => false,
          );
          print('Logged in');
        },
        child: Container(
          margin: EdgeInsets.only(top:15),
          width: size.width * 0.32,
          height: 35,
          child: Center(
              child: Text(
                "LOGIN",
                style: TextStyle(
                    color: Colors.white,
                    fontFamily: "GoogleSans",
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1),
              )),
          // margin: EdgeInsets.symmetric(horizontal: 100),
          // padding: EdgeInsets.symmetric(vertical: 20,),
          decoration: BoxDecoration(
              color: Color(0xff6750A4),
              borderRadius: BorderRadius.all(Radius.circular(25))),
        ),
      ),
    );
  }
}



