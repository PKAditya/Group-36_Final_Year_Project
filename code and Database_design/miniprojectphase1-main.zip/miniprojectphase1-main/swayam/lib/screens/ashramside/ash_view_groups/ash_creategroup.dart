import 'package:flutter/material.dart';
import 'ash_viewgroups.dart';
import 'package:flutter/material.dart';
import 'package:swayam/screens/homescreen/homescreen.dart';

class ash_creategroup extends StatelessWidget {
  const ash_creategroup({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffFCFCFC),
      appBar: AppBar(
        iconTheme: IconThemeData(color: Color(0xff6750A4)),
        // actions: [
        //   IconButton(icon: Icon(Icons.add, size: 30), onPressed: (){}),
        //   Padding(
        //     padding: EdgeInsets.only(right: 20),
        //   ),
        // ],
        elevation: 0,
        leading: IconButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ash_viewgroups(),
                  ));
              //print('A new member added to the group');
            },
            icon: Icon(Icons.arrow_back)),
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: Text(
          "CREATE SHG",
          style: TextStyle(
            fontFamily: "Montserrat",
            fontSize: 17,
            letterSpacing: 1.2,
            color: Color(0xff6750A4),
          ),
        ),
        //title: const Text("Home Screen"),
        backgroundColor: Color(0xffFCFCFC),
      ),
      body:  Container(
        padding: EdgeInsets.only(bottom: 30),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          color: Color(0xffCCBBE7),

          // colors: [Color(0xffd3a1e7), Color(0xff7d5dde)]),
        ),
        margin: EdgeInsets.only(
          top: 40,
          left: 25,
          right: 25,
          bottom: 40,
        ),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.symmetric(vertical: 40, horizontal: 15),
                child: Text(
                  'Please enter the SHG Details.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    decorationStyle: TextDecorationStyle.solid,
                    decorationThickness: 1.5,
                    color: Colors.black,
                    fontFamily: 'GoogleSans',
                    fontSize: 15,
                  ),
                ),
              ),
              ash_groupName(),
              ash_groupLocation(),
              ash_mainAdminPhone(),
              ash_getNewShg(),
            ],
          ),
        ),
      ),

    );
  }
}





//widgets used--------------------------------------------

Widget ash_groupName() {
  return Container(
    margin: EdgeInsets.only(left: 30, right: 30, bottom: 10),
    child: TextFormField(
      autovalidateMode: AutovalidateMode.always,
      //keyboardType: TextInputType.emailAddress,
      //obscureText: true,
      textInputAction: TextInputAction.next,
      cursorColor: Color(0xff6750A4),
      style: TextStyle(
        color: Colors.black54,
        fontSize: 14,
        fontFamily: 'Ubuntu',
        fontWeight: FontWeight.bold,
      ),
      //onSaved: (email) {},
      //controller: ,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(25)),
          borderSide: const BorderSide(color: Color(0xff6750A4)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(20)),
          borderSide: const BorderSide(color: Color(0xff6750A4)),
        ),
        //labelText: 'Type in your Username',
        labelStyle: TextStyle(
          color: Colors.black54,
          fontSize: 14,
          fontFamily: 'GoogleSans',
          fontWeight: FontWeight.bold,
        ),
        contentPadding: EdgeInsets.only(top: 14),
        prefixIcon: Icon(Icons.abc, color: Colors.black54),
        hintText: "SHG Name",
        hintStyle: TextStyle(
          color: Colors.black54,
          fontSize: 14,
          fontFamily: 'GoogleSans',
          fontWeight: FontWeight.bold,
        ),
      ),
    ),
  );
}
Widget ash_groupLocation() {
  return Container(
    margin: EdgeInsets.only(left: 30, right: 30, bottom: 10),
    child: TextFormField(
      autovalidateMode: AutovalidateMode.always,
      //keyboardType: TextInputType.emailAddress,
      //obscureText: true,
      textInputAction: TextInputAction.next,
      cursorColor: Color(0xff6750A4),
      style: TextStyle(
        color: Colors.black54,
        fontSize: 14,
        fontFamily: 'Ubuntu',
        fontWeight: FontWeight.bold,
      ),
      //onSaved: (email) {},
      //controller: ,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(25)),
          borderSide: const BorderSide(color: Color(0xff6750A4)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(20)),
          borderSide: const BorderSide(color: Color(0xff6750A4)),
        ),
        //labelText: 'Type in your Username',
        labelStyle: TextStyle(
          color: Colors.black54,
          fontSize: 14,
          fontFamily: 'GoogleSans',
          fontWeight: FontWeight.bold,
        ),
        contentPadding: EdgeInsets.only(top: 14),
        prefixIcon: Icon(Icons.abc, color: Colors.black54),
        hintText: "SHG Location",
        hintStyle: TextStyle(
          color: Colors.black54,
          fontSize: 14,
          fontFamily: 'GoogleSans',
          fontWeight: FontWeight.bold,
        ),
      ),
    ),
  );
}
Widget ash_mainAdminPhone() {
  return Container(
    margin: EdgeInsets.only(left: 30, right: 30, bottom: 10),
    child: TextFormField(
      autovalidateMode: AutovalidateMode.always,
      keyboardType: TextInputType.phone,
      //obscureText: true,
      textInputAction: TextInputAction.next,
      cursorColor: Color(0xff6750A4),
      style: TextStyle(
        color: Colors.black54,
        fontSize: 14,
        fontFamily: 'Ubuntu',
        fontWeight: FontWeight.bold,
      ),
      //onSaved: (email) {},
      //controller: ,
      decoration: InputDecoration(
        filled: true,
        fillColor: Colors.white,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(25)),
          borderSide: const BorderSide(color: Color(0xff6750A4)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(20)),
          borderSide: const BorderSide(color: Color(0xff6750A4)),
        ),
        //labelText: 'Type in your Username',
        labelStyle: TextStyle(
          color: Colors.black54,
          fontSize: 14,
          fontFamily: 'GoogleSans',
          fontWeight: FontWeight.bold,
        ),
        contentPadding: EdgeInsets.only(top: 14),
        prefixIcon: Icon(Icons.phone, color: Colors.black54),
        hintText: "President Phone Number",
        hintStyle: TextStyle(
          color: Colors.black54,
          fontSize: 14,
          fontFamily: 'GoogleSans',
          fontWeight: FontWeight.bold,
        ),
      ),
    ),
  );
}

class ash_getNewShg extends StatelessWidget {
  const ash_getNewShg({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      margin: EdgeInsets.symmetric(vertical: 20),
      child: InkWell(
        onTap: () async {
          await Future.delayed(
            Duration(seconds: 1),
          );
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => ash_viewgroups(),
              ));
          print('SHG created');
        },
        child: Container(
          width: size.width * 0.6,
          height: 55,
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Image.asset("images/icons/add.png", height: 50, width: 50),
                    // SizedBox(width: 20),
                    Center(
                      child: Text(
                        "CREATE SHG",
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: "Poppins",
                          fontWeight: FontWeight.bold,
                          shadows: [
                            Shadow(
                              offset: Offset(0.1, 0.1),
                              blurRadius: 5.0,
                              color: Colors.black,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // margin: EdgeInsets.symmetric(horizontal: 100),
          // padding: EdgeInsets.symmetric(vertical: 20,),
          decoration: BoxDecoration(
              color: Color(0xff6750A4),
              borderRadius: BorderRadius.all(Radius.circular(25))),
        ),
      ),
    );
  }
}