import 'package:flutter/material.dart';
import 'package:swayam/screens/homescreen/homescreen.dart';
import 'package:swayam/screens/ashramside/ash_home/ash_dashboard.dart';
import 'ash_creategroup.dart';
import 'package:swayam/screens/ashramside/ash_home/ash_dashboard.dart';

class ash_viewgroups extends StatelessWidget {
  const ash_viewgroups({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffFCFCFC),
      appBar: AppBar(
        iconTheme: IconThemeData(color: Color(0xff6750A4)),
        actions: [
          IconButton(
              icon: Icon(Icons.add, size: 30),
              onPressed: () {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ash_creategroup(),
                    ));
              }),
          Padding(
            padding: EdgeInsets.only(right: 20),
          ),
        ],
        elevation: 0,
        leading: IconButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ashhomescreen(),
                  ));
              //print('A new member added to the group');
            },
            icon: Icon(Icons.arrow_back)),
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: Text(
          "VIEW SHGS",
          style: TextStyle(
            fontFamily: "Montserrat",
            fontSize: 17,
            letterSpacing: 1.2,
            color: Color(0xff6750A4),
          ),
        ),
        //title: const Text("Home Screen"),
        backgroundColor: Color(0xffFCFCFC),
      ),
      body: SingleChildScrollView(
        child: get_clust_mems(),
      ),
    );
  }
}

//widgets used--------------------------------------------

Widget get_clust_mems() {
  return SingleChildScrollView(
    scrollDirection: Axis.horizontal,
    child: Container(
      margin: EdgeInsets.fromLTRB(18, 25, 18, 25),
      child: DataTable(
        headingRowColor:
            MaterialStateColor.resolveWith((states) => Color(0xff6750A4)),
        headingTextStyle: TextStyle(
          fontFamily: "Montserrat-Bold",
          fontSize: 13,
          color: Colors.white,
          //fontWeight: FontWeight.bold,
          //fontStyle: FontStyle.italic,
        ),
        dataTextStyle: TextStyle(
            fontFamily: "Poppins",
            fontSize: 11,
            color: Color(0xff6750A4),
            fontWeight: FontWeight.bold),
        //border: TableBorder(horizontalInside:BorderSide(style: BorderStyle.solid, color: Colors.grey),) ,

        columns: [
          DataColumn(
            label: Expanded(
              child: Text(
                'S.NO',
              ),
            ),
          ), //S.NO
          DataColumn(
            label: Expanded(
              child: Text(
                'GROUP I.D.',
              ),
            ),
          ), //GROUP ID
          DataColumn(
            label: Expanded(
              child: Text(
                'LOCATION',
              ),
            ),
          ), //LOCATION
          DataColumn(
            label: Expanded(
              child: Text(
                'SHG PRESIDENT',
              ),
            ),
          ),
          DataColumn(
            label: Expanded(
              child: Text(
                '',
              ),
            ),
          ), //GROUP HEAD
        ],
        rows: const <DataRow>[
          DataRow(
            cells: <DataCell>[
              DataCell(
                Text(
                  '1',
                ),
              ),
              DataCell(Text(
                'XXXXXXXXX',
              )),
              DataCell(Text(
                'Amritapuri',
              )),
              DataCell(Text(
                'Shruthi',
              )),
              DataCell(
                get_role(),

              ),
            ],
          ),
          DataRow(
            cells: <DataCell>[
              DataCell(
                Text(
                  '2',
                ),
              ),
              DataCell(Text(
                'XXXXXXXXX',
              )),
              DataCell(Text(
                'Allapuzha',
              )),
              DataCell(Text(
                'Lekshmi',
              )),
              DataCell(
                  get_role()
              ),
            ],
          ),
          DataRow(
            cells: <DataCell>[
              DataCell(
                Text(
                  '3',
                ),
              ),
              DataCell(Text(
                'XXXXXXXXX',
              )),
              DataCell(Text(
                'Kochi',
              )),
              DataCell(Text(
                'Rekha',
              )),
              DataCell(
                  get_role()
              ),
            ],
          ),
          DataRow(
            cells: <DataCell>[
              DataCell(
                Text(
                  '4',
                ),
              ),
              DataCell(Text(
                'XXXXXXXXX',
              )),
              DataCell(Text(
                'Karunagapalli',
              )),
              DataCell(Text(
                'Mani',
              )),
              DataCell(
                  get_role()
              ),
            ],
          ),
          DataRow(
            cells: <DataCell>[
              DataCell(
                Text(
                  '5',
                ),
              ),
              DataCell(Text(
                'XXXXXXXXX',
              )),
              DataCell(Text(
                'Kayankulam',
              )),
              DataCell(Text(
                'Sree Lakshmi',
              )),
              DataCell(
                  get_role(),
              ),
            ],
          ),
          DataRow(
            cells: <DataCell>[
              DataCell(
                Text(
                  '6',
                ),
              ),
              DataCell(Text(
                'XXXXXXXXX',
              )),
              DataCell(Text(
                'Kollam',
              )),
              DataCell(Text(
                'Nada Shree',
              )),
              DataCell(
                get_role(),
              ),
            ],
          ),
          DataRow(
            cells: <DataCell>[
              DataCell(
                Text(
                  '7',
                ),
              ),
              DataCell(Text(
                'XXXXXXXXX',
              )),
              DataCell(Text(
                'Azheekal',
              )),
              DataCell(Text(
                'Kalyani',
              )),
              DataCell(
                get_role(),
              ),
            ],
          ),
          DataRow(
            cells: <DataCell>[
              DataCell(
                Text(
                  '8',
                ),
              ),
              DataCell(Text(
                'XXXXXXXXX',
              )),
              DataCell(Text(
                'Cheer Azheekal',
              )),
              DataCell(Text(
                'Jayashree',
              )),
              DataCell(
                get_role(),
              ),
            ],
          ),
          DataRow(
            cells: <DataCell>[
              DataCell(
                Text(
                  '9',
                ),
              ),
              DataCell(Text(
                'XXXXXXXXX',
              )),
              DataCell(Text(
                'Varkala Sivagiri',
              )),
              DataCell(Text(
                'Sudha',
              )),
              DataCell(
                get_role(),
              ),
            ],
          ),
          DataRow(
            cells: <DataCell>[
              DataCell(
                Text(
                  '10',
                ),
              ),
              DataCell(Text(
                'XXXXXXXXX',
              )),
              DataCell(Text(
                'Oachira',
              )),
              DataCell(Text(
                'Jyothi',
              )),
              DataCell(
                get_role(),
              ),
            ],
          ),
        ],
      ),
    ),
  );
}

//--------------------Widgets used

class get_role extends StatefulWidget {
  const get_role({Key? key}) : super(key: key);

  @override
  State<get_role> createState() => _get_roleState();
}

class _get_roleState extends State<get_role> {
  @override
  final roles = ["Edit SHG Details", "Edit Admins", "View SHG"];
  String? _selectedVal = "";

  Widget build(BuildContext context) {
    return Container(
      //height: 45,
      // margin: EdgeInsets.only(left: 55, right: 55, top: 10),
      // padding: EdgeInsets.only( right: 10),
      // decoration: BoxDecoration(
      //   color: Colors.white,
      //   borderRadius: BorderRadius.all(Radius.circular(25)),
      // ),
      child: DropdownButton(
        icon: Icon(
          Icons.more_vert_outlined,

        ),
        items: roles
            .map(
              (e) => DropdownMenuItem(child: Text(e), value: e),
            )
            .toList(),
        onChanged: (String? newValue) {
          setState(() {
            _selectedVal = newValue!;
          });
        },
      ),
      // DropdownButtonFormField(
      //   decoration: InputDecoration(
      //     filled: true,
      //     fillColor: Colors.white,
      //     border: OutlineInputBorder(
      //       borderRadius: BorderRadius.all(Radius.circular(25)),
      //       borderSide: const BorderSide(color: Color(0xFFFF005B)),
      //     ),
      //     focusedBorder: OutlineInputBorder(
      //       borderRadius: BorderRadius.all(Radius.circular(20)),
      //       borderSide: const BorderSide(color: Color(0xFFFF005B)),
      //     ),
      //
      //     prefixIcon:
      //     Icon(Icons.accessibility_new_rounded, color: Colors.black54),
      //   ),
      //   icon: const Icon(
      //     Icons.arrow_drop_down_circle,
      //     color: Color(0xFFFF005B),
      //   ),
      //   hint: Text("Select your role",
      //       style: TextStyle(
      //         color: Colors.black54,
      //         fontSize: 14,
      //         fontFamily: 'GoogleSans',
      //         fontWeight: FontWeight.bold,
      //       )),
      //   items: roles
      //       .map(
      //         (e) => DropdownMenuItem(child: Text(e), value: e),
      //   )
      //       .toList(),
      //   onChanged: (val) {
      //     setState(() {
      //       _selectedVal = val as String;
      //     });
      //   },
      // ),
    );
  }
}
