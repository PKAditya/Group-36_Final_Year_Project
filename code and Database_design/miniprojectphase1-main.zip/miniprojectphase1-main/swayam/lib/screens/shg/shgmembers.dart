import 'package:flutter/material.dart';
import 'package:swayam/screens/homescreen/homescreen.dart';
import 'members/addmem.dart';
import 'members/member_details.dart';

class shgmems extends StatefulWidget {
  const shgmems({Key? key}) : super(key: key);

  @override
  State<shgmems> createState() => _shgmemsState();
}

class _shgmemsState extends State<shgmems> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffFCFCFC),
      appBar: AppBar(
        iconTheme: IconThemeData(color: Color(0xff6750A4)),
        actions: [
          IconButton(
              icon: Icon(Icons.add, size: 30),
              onPressed: () {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => AddUser(),
                    ));
              }),
          Padding(
            padding: EdgeInsets.only(right: 20),
          ),
        ],
        elevation: 0,
        leading: IconButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => homescreen(),
                  ));
              //print('A new member added to the group');
            },
            icon: Icon(Icons.arrow_back)),
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: Text(
          "SHG MEMBERS",
          style: TextStyle(
            fontFamily: "Montserrat",
            fontSize: 17,
            letterSpacing: 1.2,
            color: Color(0xff6750A4),
          ),
        ),
        //title: const Text("Home Screen"),
        backgroundColor: Color(0xffFCFCFC),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            group_mem(),
          ],
        ),
      ),
    );
    ;
  }
}

//widgets used--------------------------------------------

class group_mem extends StatefulWidget {
  const group_mem({Key? key}) : super(key: key);

  @override
  State<group_mem> createState() => _group_memState();
}

class _group_memState extends State<group_mem> {
  bool _sliderValue = true;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 10),
        margin: EdgeInsets.symmetric(horizontal: 20,vertical: 30),
        child: Column(
          children: [
            InkWell(
              onTap: () {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => memberDetailsScreen(),
                    ));
              },
              child: Container(
                decoration: BoxDecoration(color: Color(0xffFFFBFE),),
                child: Column(
                  children: [
                    Container(
                      //margin: EdgeInsets.symmetric(),
                      decoration: BoxDecoration(
                          //color: Color(0xffFFFBFE),
                          //border: Border.all(color: Colors.grey),
                          //borderRadius: BorderRadius.circular(8.0),

                          ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                CircleAvatar(
                                  backgroundImage: NetworkImage(
                                      'https://images.pexels.com/photos/3934783/pexels-photo-3934783.jpeg?auto=compress&cs=tinysrgb&w=600'), // or AssetImage if local image
                                  radius: 30.0,
                                  backgroundColor: Colors.grey,
                                ),
                                SizedBox(width: 16.0),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Aakanksha Devi',
                                        style: TextStyle(
                                          fontFamily: 'Prompt',
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16.0,
                                        ),
                                      ),
                                      SizedBox(height: 3.0),
                                      Text(
                                        'SHG Member',
                                        style: TextStyle(
                                          fontFamily: 'Prompt',
                                          fontSize: 12.0,
                                        ),
                                      ),
                                      SizedBox(height: 3.0),
                                      Text(
                                        'AmritaSree, Ira Kuttanad, Kerala',
                                        style: TextStyle(
                                          fontFamily: 'Prompt',
                                          fontSize: 12.0,
                                        ),
                                      ),
                                      SizedBox(height: 8.0),
                                    ],
                                  ),
                                ),
                                SizedBox(width: 16.0),
                                GestureDetector(
                                  onTap: () {
                                    if (_sliderValue) { // show dialog only if slider is currently off
                                      showDialog(
                                        context: context,
                                        builder: (BuildContext context) {
                                          return AlertDialog(
                                            shape: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                                            title: Text('DISABLE MEMBER?',style: TextStyle(fontFamily: "Montserrat",color: Color(0xff6750A4),fontSize: 16),textAlign: TextAlign.center),
                                            content: Text(
                                                'This will disable the member from Svayam and she will no longer be able to access this app. Are you sure you want to proceed?',
                                            style: TextStyle(fontFamily: 'Prompt',fontSize: 11.5),
                                            ),
                                            actions: <Widget>[
                                              TextButton(
                                                child: Text('Cancel',style: TextStyle(fontFamily: 'Prompt')),
                                                onPressed: () {
                                                  Navigator.of(context).pop();
                                                },
                                              ),
                                              TextButton(
                                                child: Container(
                                                  padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                                                  decoration: BoxDecoration(
                                                    color: Colors.purple,
                                                    borderRadius: BorderRadius.circular(8.0),
                                                  ),
                                                  child: Text(
                                                    'Yes',
                                                    style: TextStyle(
                                                      fontFamily: 'Prompt',
                                                      color: Colors.white,
                                                      fontWeight: FontWeight.bold,
                                                    ),
                                                  ),
                                                ),
                                                onPressed: () {
                                                  setState(() {
                                                    _sliderValue = false; // turn off the slider
                                                  });
                                                  Navigator.of(context).pop();
                                                },
                                              ),
                                            ],
                                          );
                                        },
                                      );
                                    } else {
                                      setState(() {
                                        _sliderValue = true ; // turn on the slider again
                                      });
                                    }
                                  },
                                  child: Container(
                                    width: 50.0,
                                    height: 30.0,
                                    decoration: BoxDecoration(
                                      borderRadius: BorderRadius.circular(16.0),
                                      color: _sliderValue ? Colors.purple : Colors.grey,
                                    ),
                                    child: Padding(
                                      padding: const EdgeInsets.all(4.0),
                                      child: Align(
                                        alignment: _sliderValue
                                            ? Alignment.centerRight
                                            : Alignment.centerLeft,
                                        child: Container(
                                          width: 22.0,
                                          height: 22.0,
                                          decoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                            color: Colors.white,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),

                              ],
                            ),
                            InkWell(
                              onTap: () {
                                showModalBottomSheet(
                                  shape: OutlineInputBorder(borderRadius: BorderRadius.only(topRight: Radius.circular(20),topLeft: Radius.circular(20))),
                                  context: context,
                                  builder: (BuildContext context) {
                                    return Container(

                                      child: Column(
                                        mainAxisSize: MainAxisSize.min,
                                        children: [
                                          Container(
                                              decoration: BoxDecoration(
                                                  borderRadius:
                                                      BorderRadius.circular(100)),

                                              child: Text(
                                                "SELECT AN OPTION",
                                                style: TextStyle(
                                                  fontSize: 15,
                                                  color: Color(0xff6750A4),
                                                  letterSpacing: 1.2,
                                                  fontFamily: "Montserrat",
                                                ),
                                              ),
                                            padding: EdgeInsets.symmetric(vertical: 15),
                                          ),
                                          SizedBox(
                                            width: 300,
                                            height: 15,
                                            child: Divider(
                                              color: Colors.black,
                                            ),
                                          ),
                                          InkWell(
                                            child: Padding(
                                              padding: EdgeInsets.all(16),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Icon(Icons.textsms,
                                                      color: Colors.blue,
                                                      shadows: [
                                                        Shadow(color: Colors.black)
                                                      ]),
                                                  Text('Text Message'),
                                                ],
                                              ),
                                            ),
                                            onTap: () {
                                              // Perform action for Text
                                              Navigator.pop(context);
                                            },
                                          ),
                                          Divider(),
                                          InkWell(
                                            child: Padding(
                                              padding: EdgeInsets.all(16),
                                              child: Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.spaceBetween,
                                                children: [
                                                  Icon(Icons.call,
                                                      shadows: [
                                                        Shadow(color: Colors.black)
                                                      ],
                                                      color: Colors.green.shade600),
                                                  Text('Phone Call'),
                                                ],
                                              ),
                                            ),
                                            onTap: () {
                                              // Perform action for Call
                                              Navigator.pop(context);
                                            },
                                          ),
                                        ],
                                      ),
                                    );
                                  },
                                );
                              },
                              child: Padding(
                                padding: EdgeInsets.symmetric(vertical: 15),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Icon(Icons.phone,
                                            size: 18,
                                            color: Colors.green.shade600,
                                            shadows: [Shadow(color: Colors.black)]),
                                        SizedBox(width: 8.0),
                                        Text(
                                          '9100861969',
                                          style: TextStyle(
                                            fontFamily: 'Prompt',
                                            fontSize: 13.0,
                                          ),
                                        ),

                                      ],
                                    ),
                                    Icon(Icons.arrow_right_outlined),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      child: SizedBox(
                        width: 300,
                        height: 5,
                        child: Divider(
                          color: Colors.grey,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}


