import 'package:flutter/material.dart';
import '../shgmembers.dart';
import 'edit_member_details.dart';



class memberDetailsScreen extends StatefulWidget {
  const memberDetailsScreen({Key? key}) : super(key: key);

  @override
  State<memberDetailsScreen> createState() => _memberDetailsScreenState();
}
class _memberDetailsScreenState extends State<memberDetailsScreen> {
  final List<Tab> tabs = [
    Tab(text: 'User Info'),
    Tab(text: 'Security'),
  ];

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: tabs.length,
      child: Scaffold(
        appBar: AppBar(
          iconTheme: IconThemeData(color: Color(0xffa69be0)),
          title: Text(
            "AAKANKSHA DEVI",
            style: TextStyle(
              fontFamily: "Montserrat",
              fontSize: 17,
              letterSpacing: 1.2,
              color: Color(0xff6750A4),
            ),
          ),
          //title: const Text("Home Screen"),
          backgroundColor: Colors.purple[50],
          leading: IconButton(
              onPressed: () {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => shgmems(),
                    ));
                //print('A new member added to the group');
              },
              icon: Icon(Icons.arrow_back)),
        ),
        body: Column(
          children: [
            Container(
              color: Color(0xffFCFCFC), // set the TabBar background color
              child: TabBar(
                tabs: tabs,
                indicatorColor: Colors.purple, // set the TabBar indicator color
                labelColor: Colors.black,
                unselectedLabelColor: Colors.black.withOpacity(0.4),
              ),
            ),
            Expanded(
              child: TabBarView(
                children: [
                  UserInfoScreen(),
                  SecurityScreen(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}






class UserInfoScreen extends StatefulWidget {
  const UserInfoScreen({Key? key}) : super(key: key);

  @override
  State<UserInfoScreen> createState() => _UserInfoScreenState();
}
class _UserInfoScreenState extends State<UserInfoScreen> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Color(0xffFCFCFC),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(45.0),
              child: Container(
                decoration: BoxDecoration(
                    border: Border.all(width: 15, color: Color(0xffCCBBE7)),
                    borderRadius: BorderRadius.circular(110)),
                child: CircleAvatar(
                  backgroundImage: NetworkImage(
                      'https://images.pexels.com/photos/3934783/pexels-photo-3934783.jpeg?auto=compress&cs=tinysrgb&w=600'), // or AssetImage if local image
                  radius: 70.0,
                  backgroundColor: Colors.grey,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Basic Info',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),
                  Text(
                    'Full Name: ',
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    'Aakanksha Devi',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  SizedBox(height: 13.0),
                  Text(
                    'Mobile Number: ',
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    '9100861969',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  SizedBox(height: 13.0),
                  Text(
                    'Email Address: ',
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    '-',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'System Role',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),
                  Text(
                    'Account Type ',
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    'SHG Members',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'SHG Assignment',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),
                  Text(
                    'SHG ',
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'AmritaSree',
                        style: TextStyle(
                          fontSize: 14.0,
                        ),
                      ),
                      TextButton(
                          onPressed: () {},
                          child: Text(
                            "View SHG Details",
                            style: TextStyle(
                                color: Color(0xff6750A4), fontSize: 14),
                          ))
                    ],
                  ),
                  SizedBox(height: 13.0),
                  Text(
                    'SHG Role ',
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Member',
                        style: TextStyle(
                          fontSize: 14.0,
                        ),
                      ),
                      TextButton(
                          onPressed: () {},
                          child: Text(
                            "View Member Details",
                            style: TextStyle(
                                color: Color(0xff6750A4), fontSize: 14),
                          ))
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      floatingActionButton: InkWell(
        onTap: () {
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => EditDetails(),
              ));
        },
        child: Container(
          width: 50.0,
          height: 50.0,
          decoration: BoxDecoration(
            color: Color(0xffEADDFF),
            borderRadius: BorderRadius.circular(8.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey,
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Icon(Icons.mode_edit_outline_outlined),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}


class SecurityScreen extends StatefulWidget {
  const SecurityScreen({Key? key}) : super(key: key);

  @override
  State<SecurityScreen> createState() => _SecurityScreenState();
}
class _SecurityScreenState extends State<SecurityScreen> {
  final _formKey = GlobalKey<FormState>();
  final _passwordController = TextEditingController();
  // bool _isPasswordVisible = false;

  // void _togglePasswordVisibility() {
  //   setState(() {
  //     _isPasswordVisible = !_isPasswordVisible;
  //   });
  // }

  void showOverridePasswordDialog(BuildContext context) {
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Override Password"),
      shape: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),

      content: Form(
        key: _formKey,
        child: SizedBox(height: 200,child: PasswordFormField()),
      ),
      actions: [
        TextButton(
          child: Text("Cancel"),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        ElevatedButton(
          child: Text("Save"),
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              // Perform password override here
              String password = _passwordController.text;
              print("Password overridden: $password");
              Navigator.of(context).pop();
              showFinshedOverridingAlertDialog(context);
            }
          },
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all<Color>(Colors.purple[200]!),
            shape: MaterialStateProperty.all<RoundedRectangleBorder>(
              RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18.0),
              ),
            ),
          ),
        ),
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }

  void showFinshedOverridingAlertDialog(BuildContext context) {
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      shape: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
      title: Column(
        children: [
          Image.asset("assets/icons/checkmark.png",width: 45),
          Padding(padding: EdgeInsets.only(top: 20,bottom:10),child: Text("Password overridden successfully",style: TextStyle(fontSize: 11.5),)),
        ],
      ),
      actions: [
        ElevatedButton(
          child: Text("OK",style: TextStyle(color: Colors.black),),
          onPressed: () {
            Navigator.of(context).pop();
          },
          style: ButtonStyle(
            shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
            backgroundColor: MaterialStateProperty.all<Color>(Color(0xffdacce3)),
            minimumSize: MaterialStateProperty.all<Size>(Size(double.infinity, 50)),
          ),
        ),
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },);}

  void showForceChangeAlertDialog(BuildContext context) {
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      shape: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
      title: Column(
        children: [
          Image.asset("assets/icons/checkmark.png",width: 45),
          Padding(padding: EdgeInsets.only(top: 20,bottom:10),child: Text("Force change password enforced successfully",style: TextStyle(fontSize: 11.5),)),
        ],
      ),
      actions: [
        ElevatedButton(
          child: Text("OK",style: TextStyle(color: Colors.black),),
          onPressed: () {
            Navigator.of(context).pop();
          },
          style: ButtonStyle(
            shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
            backgroundColor: MaterialStateProperty.all<Color>(Color(0xffdacce3)),
            minimumSize: MaterialStateProperty.all<Size>(Size(double.infinity, 50)),
          ),
        ),
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },);}


  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Color(0xffFCFCFC),
      body: SingleChildScrollView(
        child: Column(
          children: [
            //override password
            Container(
              margin: EdgeInsets.symmetric(vertical: 20, horizontal: 20),
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffdacce3),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              //color: Color(0xffCAC4D0),
              child: Column(
                children: [
                  //Image
                  Container(
                    //height: 200,
                    child: ClipRRect(
                        child: Image.asset(
                          'assets/images/override_password.jpg', fit: BoxFit.fitWidth,
                        ),
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20))),
                  ),
                  //Text Info
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 20,horizontal: 20),
                    child: Text("Override a user's password using below button."),
                    alignment: Alignment.centerLeft,
                  ),
                  //Button
                  Container(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () {showOverridePasswordDialog(context);},
                      child: Text(
                        "Override Password",
                        style: TextStyle(fontWeight: FontWeight.bold,color: Color(0xff6750A4), fontSize: 14),
                      ),
                    ),
                  )
                ],
              ),
            ),
            //ForceChange
            Container(
              margin: EdgeInsets.only(bottom: 20, left: 20, right:20),
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffdacce3),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              //color: Color(0xffCAC4D0),
              child: Column(
                children: [
                  //Image
                  Container(
                    //height: 200,
                    child: ClipRRect(
                        child: Image.asset(
                          'assets/images/force_change_pass.jpeg', fit: BoxFit.fitWidth,
                        ),
                        borderRadius: BorderRadius.only(
                            topLeft: Radius.circular(20),
                            topRight: Radius.circular(20))),
                  ),
                  //Text Info
                  Container(
                    padding: EdgeInsets.symmetric(vertical: 20,horizontal: 20),
                    child: Text("Force user to receive OTP & change password when she log in next using below button."),
                    alignment: Alignment.centerLeft,
                  ),
                  //Button
                  Container(
                    alignment: Alignment.centerRight,
                    child: TextButton(
                      onPressed: () {showForceChangeAlertDialog(context);},
                      child: Text(
                        "Force Change Password",
                        style: TextStyle(fontWeight: FontWeight.bold,color: Color(0xff6750A4), fontSize: 14),
                      ),
                    ),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}


class PasswordFormField extends StatefulWidget {
  const PasswordFormField({Key? key}) : super(key: key);

  @override
  _PasswordFormFieldState createState() => _PasswordFormFieldState();
}
class _PasswordFormFieldState extends State<PasswordFormField> {
  bool _obscureText = true;
  bool _containsAlphabetic = false;
  bool _containsNumeric = false;
  bool _isLongEnough = false;

  void _validatePassword(String value) {
    setState(() {
      _containsAlphabetic = value.contains(RegExp(r'[a-zA-Z]'));
      _containsNumeric = value.contains(RegExp(r'[0-9]'));
      _isLongEnough = value.length >= 10;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextFormField(
          obscureText: _obscureText,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            labelText: 'Enter new password',
            labelStyle: TextStyle(fontSize: 12),
            suffixIcon: IconButton(
              icon: Icon(_obscureText
                  ? Icons.visibility_outlined
                  : Icons.visibility_off_outlined),
              onPressed: () {
                setState(() {
                  _obscureText = !_obscureText;
                });
              },
            ),
          ),
          onChanged: _validatePassword,
          validator: (value) {
            if (!_containsAlphabetic && !_isLongEnough && !_containsNumeric){
              return 'Field can not be empty';
            }
            if (!_containsAlphabetic) {
              return 'Password must contain alphabetic characters';
            }
            if (!_containsNumeric) {
              return 'Password must contain numeric characters';
            }
            if (!_isLongEnough) {
              return 'Password must be at least 10 characters long';
            }
            return null;
          },
        ),
        SizedBox(height: 15),
        Text("Password must",style: TextStyle(fontSize: 14,fontWeight: FontWeight.bold,)),
        SizedBox(height: 8),
        Row(
          children: [

            Icon(
              _containsAlphabetic ? Icons.check_circle : Icons.error_outline_outlined,
              color: _containsAlphabetic ? Colors.green : Colors.red,
            ),
            SizedBox(width: 8),
            Text(
              'Contain at least one alphabetic character',
              style: TextStyle(
                fontSize: 12,
              ),
            ),
          ],
        ),
        Row(
          children: [
            Icon(
              _containsNumeric ? Icons.check_circle : Icons.error_outline_outlined,
              color: _containsNumeric ? Colors.green : Colors.red,
            ),
            SizedBox(width: 8),
            Text(
              'Contain at least one numeric character',
              style: TextStyle(
                fontSize: 12,
              ),
            ),
          ],
        ),
        Row(
          children: [
            Icon(
              _isLongEnough ? Icons.check_circle : Icons.error_outline_outlined,
              color: _isLongEnough ? Colors.green : Colors.red,
            ),
            SizedBox(width: 8),
            Text(
              'Be at least 10 characters long',
              style: TextStyle(
                fontSize: 12,
              ),
            ),
          ],
        ),
      ],
    );
  }
}