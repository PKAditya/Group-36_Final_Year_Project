import 'package:flutter/material.dart';
import 'member_details.dart';

class EditDetails extends StatefulWidget {
  const EditDetails({Key? key}) : super(key: key);

  @override
  State<EditDetails> createState() => _EditDetailsState();
}

class _EditDetailsState extends State<EditDetails> {
  String? selectedSystemRole;
  String? selectedShgAssignment;
  Widget _buildOptionSystemRole(String title) {
    final bool isSelected = title == selectedSystemRole;
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedSystemRole = title;
        });
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 7.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12.0),
          border: Border.all(color: Colors.grey),
          color: isSelected ? Color(0xffE8DEF8) : Colors.white,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            if (isSelected)
              Icon(
                Icons.check,
                color: Colors.black,
                size: 15,
              ),
            Text(
              title,
              style: TextStyle(
                //color: isSelected ? Colors.white : Colors.black,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  } //choice option thingy
  Widget _anotherBuildOptionSHG(String title) {
    final bool isSelected = title == selectedShgAssignment;
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedShgAssignment = title;
        });
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 7.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12.0),
          border: Border.all(color: Colors.grey),
          color: isSelected ? Color(0xffE8DEF8) : Colors.white,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            if (isSelected)
              Icon(
                Icons.check,
                color: Colors.black,
                size: 15,
              ),
            Text(
              title,
              style: TextStyle(
                //color: isSelected ? Colors.white : Colors.black,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  } //Another choice option thingy
  void showUserEditedDialog(BuildContext context) {
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      shape: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
      title: Column(
        children: [
          Image.asset("assets/icons/checkmark.png",width: 45),
          Padding(padding: EdgeInsets.only(top: 20,bottom:10),child: Text("Edited User successfully",style: TextStyle(fontSize: 11.5),)),
        ],
      ),
      actions: [
        ElevatedButton(
          child: Text("OK",style: TextStyle(color: Colors.black),),
          onPressed: () {
            Navigator.of(context).pop();
          },
          style: ButtonStyle(
            shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
            backgroundColor: MaterialStateProperty.all<Color>(Color(0xffdacce3)),
            minimumSize: MaterialStateProperty.all<Size>(Size(double.infinity, 50)),
          ),
        ),
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },);}
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _shgController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Color(0xff6750A4)),
        title: Text(
          "EDIT USER",
          style: TextStyle(
            fontFamily: "Montserrat",
            fontSize: 17,
            letterSpacing: 1.2,
            color: Color(0xff6750A4),
          ),
        ),
        //title: const Text("Home Screen"),
        backgroundColor: Colors.purple[50],
        leading: IconButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => memberDetailsScreen(),
                  ));
              //print('A new member added to the group');
            },
            icon: Icon(Icons.arrow_back)),
        actions: [
          IconButton(
            icon: Text(
              "Save",
              style: TextStyle(color: Color(0xff6750A4)),
            ),
            onPressed: () {
              showModalBottomSheet(
                shape: OutlineInputBorder(borderRadius: BorderRadius.only(topRight: Radius.circular(20),topLeft: Radius.circular(20))),
                context: context,
                builder: (BuildContext context) {
                  return Container(
                    decoration: BoxDecoration(
                      //color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(100),
                        topRight: Radius.circular(100),
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100)),
                          child: Text(
                            "EXIT WITHOUT SAVING?",
                            style: TextStyle(
                              fontSize: 15,
                              color: Color(0xff6750A4),
                              letterSpacing: 1.2,
                              fontFamily: "Montserrat",
                            ),
                            textAlign: TextAlign.left,
                          ),
                          padding: EdgeInsets.symmetric(vertical: 15),
                        ),
                        SizedBox(
                          width: 300,
                          height: 15,
                          child: Divider(
                            color: Colors.black,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: 30,horizontal: 20),
                          child: Text(
                            'You have some unsaved changes. Do you want to save them?',
                            style:
                            TextStyle(fontFamily: 'Prompt', fontSize: 11.5),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(mainAxisAlignment: MainAxisAlignment.end,
                            children: [TextButton(
                              child: Text('Cancel',
                                  style: TextStyle(fontFamily: 'Prompt')),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                              TextButton(
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 16.0, vertical: 8.0),
                                  decoration: BoxDecoration(
                                    color: Colors.purple,
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  child: Text(
                                    'Yes',
                                    style: TextStyle(
                                      fontFamily: 'Prompt',
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                onPressed: () {
                                  showUserEditedDialog(context);
                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => memberDetailsScreen(),
                                      ));

                                },
                              ),],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
          Padding(
            padding: EdgeInsets.only(right: 20),
          ),
        ],
      ),
      backgroundColor: Color(0xffFCFCFC),
      body: SingleChildScrollView(
        child: Column(
          children: [
            //image
            Padding(
              padding: const EdgeInsets.all(45.0),
              child: Container(
                decoration: BoxDecoration(
                    border: Border.all(width: 15, color: Color(0xffCCBBE7)),
                    borderRadius: BorderRadius.circular(110)),
                child: CircleAvatar(
                  backgroundImage: NetworkImage(
                      'https://images.pexels.com/photos/3934783/pexels-photo-3934783.jpeg?auto=compress&cs=tinysrgb&w=600'), // or AssetImage if local image
                  radius: 70.0,
                  backgroundColor: Colors.grey,
                ),
              ),
            ),

            //Basic Info
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Basic Info',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Full Name: ',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [
                      Padding(
                      padding: const EdgeInsets.only(right:8.0),
                      child: Icon(Icons.account_circle_outlined),
                    ),
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.name,
                          controller: _nameController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Name',
                            hintText: 'Enter the Full Name',
                            suffixIcon: IconButton(
                              onPressed: () => _nameController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),
                  SizedBox(height: 13.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Mobile Number: ',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [Padding(
                      padding: const EdgeInsets.only(right:8.0),
                      child: Icon(Icons.phone_outlined),
                    ),
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.phone,
                          controller: _phoneNumberController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Phone Number',
                            hintText: 'Enter the Phone Number',
                            suffixIcon: IconButton(
                              onPressed: () => _phoneNumberController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),
                  SizedBox(height: 13.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Email Address: ',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [Padding(
                      padding: const EdgeInsets.only(right:8.0),
                      child: Icon(Icons.mail_outline),
                    ),
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          controller: _emailController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'E-mail',
                            hintText: 'Enter the E-mail',
                            suffixIcon: IconButton(
                              onPressed: () => _emailController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            //System Role
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'System Role',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: _buildOptionSystemRole('Sysadmin'),
                      ),
                      Expanded(
                        child: _buildOptionSystemRole('General Admin'),
                      ),
                    ],
                  ),
                  SizedBox(height: 0.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: _buildOptionSystemRole('SHG Admin'),
                      ),
                      Expanded(
                        child: _buildOptionSystemRole('SHG Member'),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            //SHG Assignment
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'SHG Assignment',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'SHG ',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [Padding(
                      padding: const EdgeInsets.only(right:8.0),
                      child: Icon(Icons.group_work_outlined),
                    ),
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.name,
                          controller: _shgController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'SHG Name',
                            hintText: 'Enter the Name of the SHG',
                            suffixIcon: IconButton(
                              onPressed: () => _shgController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),
                  SizedBox(height: 13.0),
                  Text(
                    'SHG Role ',
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      SizedBox(height: 5.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: _anotherBuildOptionSHG('President'),
                          ),
                          Expanded(
                            child: _anotherBuildOptionSHG('Secretary'),
                          ),
                        ],
                      ),
                      SizedBox(height: 0.0),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: _anotherBuildOptionSHG('Treasurer'),
                          ),
                          Expanded(
                            child: _anotherBuildOptionSHG('Member'),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
