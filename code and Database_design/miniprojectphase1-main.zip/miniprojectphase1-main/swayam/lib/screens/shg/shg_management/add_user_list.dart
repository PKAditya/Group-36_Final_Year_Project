import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:swayam/screens/shg/shg_management/shgdetails.dart';

import 'deets_member_list.dart';

class AddMemListDetails extends StatefulWidget {
  const AddMemListDetails({Key? key}) : super(key: key);

  @override
  State<AddMemListDetails> createState() => _AddMemListDetailsState();
}

class _AddMemListDetailsState extends State<AddMemListDetails> {
  String? selectedSystemRole;
  String? selectedShgAssignment;
  Widget _buildOptionSystemRole(String title) {
    final bool isSelected = title == selectedSystemRole;
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedSystemRole = title;
        });
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 7.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12.0),
          border: Border.all(color: Colors.grey),
          color: isSelected ? Color(0xffE8DEF8) : Colors.white,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            if (isSelected)
              Icon(
                Icons.check,
                color: Colors.black,
                size: 15,
              ),
            Text(
              title,
              style: TextStyle(
                //color: isSelected ? Colors.white : Colors.black,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  } //choice option thingy
  Widget _anotherBuildOptionSHG(String title) {
    final bool isSelected = title == selectedShgAssignment;
    return GestureDetector(
      onTap: () {
        setState(() {
          selectedShgAssignment = title;
        });
      },
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5.0, horizontal: 5.0),
        padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 7.0),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12.0),
          border: Border.all(color: Colors.grey),
          color: isSelected ? Color(0xffE8DEF8) : Colors.white,
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            if (isSelected)
              Icon(
                Icons.check,
                color: Colors.black,
                size: 15,
              ),
            Text(
              title,
              style: TextStyle(
                //color: isSelected ? Colors.white : Colors.black,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  } //Another choice option thingy
  void showUserEditedDialog(BuildContext context) {
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      shape: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
      title: Column(
        children: [
          Image.asset("assets/icons/checkmark.png",width: 45),
          Padding(padding: EdgeInsets.only(top: 20,bottom:10),child: Text("Edited User successfully",style: TextStyle(fontSize: 11.5),)),
        ],
      ),
      actions: [
        ElevatedButton(
          child: Text("OK",style: TextStyle(color: Colors.black),),
          onPressed: () {
            Navigator.of(context).pop();
          },
          style: ButtonStyle(
            shape: MaterialStatePropertyAll(RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
            backgroundColor: MaterialStateProperty.all<Color>(Color(0xffdacce3)),
            minimumSize: MaterialStateProperty.all<Size>(Size(double.infinity, 50)),
          ),
        ),
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },);}
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _fatherORhusbandnameController = TextEditingController();
  final TextEditingController _NomineenameController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _relationController = TextEditingController();
  final TextEditingController _phoneNumberController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _shgController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Color(0xff6750A4)),
        title: Text(
          "ADD MEMBER",
          style: TextStyle(
            fontFamily: "Montserrat",
            fontSize: 17,
            letterSpacing: 1.2,
            color: Color(0xff6750A4),
          ),
        ),
        //title: const Text("Home Screen"),
        backgroundColor: Colors.purple[50],
        leading: IconButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => shgdetails(),
                  ));
              //print('A new member added to the group');
            },
            icon: Icon(Icons.arrow_back)),
        actions: [
          IconButton(
            icon: Text(
              "Save",
              style: TextStyle(color: Color(0xff6750A4)),
            ),
            onPressed: () {
              showModalBottomSheet(
                shape: OutlineInputBorder(borderRadius: BorderRadius.only(topRight: Radius.circular(20),topLeft: Radius.circular(20))),
                context: context,
                builder: (BuildContext context) {
                  return Container(
                    decoration: BoxDecoration(
                      //color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(100),
                        topRight: Radius.circular(100),
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100)),
                          child: Text(
                            "EXIT WITHOUT SAVING?",
                            style: TextStyle(
                              fontSize: 15,
                              color: Color(0xff6750A4),
                              letterSpacing: 1.2,
                              fontFamily: "Montserrat",
                            ),
                            textAlign: TextAlign.left,
                          ),
                          padding: EdgeInsets.symmetric(vertical: 15),
                        ),
                        SizedBox(
                          width: 300,
                          height: 15,
                          child: Divider(
                            color: Colors.black,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: 30,horizontal: 20),
                          child: Text(
                            'You have some unsaved changes. Do you want to save them?',
                            style:
                            TextStyle(fontFamily: 'Prompt', fontSize: 11.5),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(mainAxisAlignment: MainAxisAlignment.end,
                            children: [TextButton(
                              child: Text('Cancel',
                                  style: TextStyle(fontFamily: 'Prompt')),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                              TextButton(
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 16.0, vertical: 8.0),
                                  decoration: BoxDecoration(
                                    color: Colors.purple,
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  child: Text(
                                    'Yes',
                                    style: TextStyle(
                                      fontFamily: 'Prompt',
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                onPressed: () {
                                  showUserEditedDialog(context);
                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => shgdetails(),
                                      ));

                                },
                              ),],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
          Padding(
            padding: EdgeInsets.only(right: 20),
          ),
        ],
      ),
      backgroundColor: Color(0xffFCFCFC),
      body: SingleChildScrollView(
        child: Column(
          children: [
            //image
            Padding(
              padding: const EdgeInsets.all(45.0),
              child: Container(
                decoration: BoxDecoration(
                    border: Border.all(width: 15, color: Color(0xffCCBBE7)),
                    borderRadius: BorderRadius.circular(110)),
                child: CircleAvatar(
                  backgroundImage: NetworkImage(
                      'https://images.pexels.com/photos/3934783/pexels-photo-3934783.jpeg?auto=compress&cs=tinysrgb&w=600'), // or AssetImage if local image
                  radius: 70.0,
                  backgroundColor: Colors.grey,
                ),
              ),
            ),

            //Basic Info
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Basic Info',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Full Name: ',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right:8.0),
                        child: Icon(Icons.account_circle_outlined),
                      ),
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.name,
                          controller: _nameController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Name',
                            hintText: 'Enter the Full Name',
                            suffixIcon: IconButton(
                              onPressed: () => _nameController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),
                  SizedBox(height: 13.0),

                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Mobile Number: ',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [Padding(
                      padding: const EdgeInsets.only(right:8.0),
                      child: Icon(Icons.phone_outlined),
                    ),
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.phone,
                          controller: _phoneNumberController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Phone Number',
                            hintText: 'Enter the Phone Number',
                            suffixIcon: IconButton(
                              onPressed: () => _phoneNumberController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),
                  SizedBox(height: 13.0),

                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'SHG Role ',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: _buildOptionSystemRole('Sysadmin'),
                      ),
                      Expanded(
                        child: _buildOptionSystemRole('General Admin'),
                      ),
                    ],
                  ),
                  SizedBox(height: 0.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: _buildOptionSystemRole('SHG Admin'),
                      ),
                      Expanded(
                        child: _buildOptionSystemRole('SHG Member'),
                      ),
                    ],
                  ),
                  SizedBox(height: 13.0),

                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Email Address: ',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [Padding(
                      padding: const EdgeInsets.only(right:8.0),
                      child: Icon(Icons.mail_outline),
                    ),
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.emailAddress,
                          controller: _emailController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'E-mail',
                            hintText: 'Enter the E-mail',
                            suffixIcon: IconButton(
                              onPressed: () => _emailController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            //Personal Info
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'Personal Info',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),

                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Husband’s / Father’s Name ',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(right:8.0),
                        child: Icon(Icons.account_circle_outlined),
                      ),
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.name,
                          controller: _fatherORhusbandnameController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Husband’s / Father’s Name',
                            hintText: 'Enter the Husband’s / Father’s Name',
                            suffixIcon: IconButton(
                              onPressed: () => _fatherORhusbandnameController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),
                  SizedBox(height: 13.0),

                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Aadhar Card Number ',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(child: Aadhar_num()),
                    ],
                  ),
                  SizedBox(height: 13.0),

                  Text(
                    'Has Bookkeeper',
                    style: TextStyle(fontSize: 12.0,color: Colors.black54),),
                  Row(
                    children: [
                      Text("Year Only"),
                      Padding(
                        padding: const EdgeInsets.only(top: 5.0, left: 25),
                        child: yearOnlySlider(),
                      ),
                    ],
                  ),
                  SizedBox(height: 13.0),


                ],
              ),
            ),

            //Nominee Details
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Nominee Details',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),

                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Nominee Name: ',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [

                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.name,
                          controller: _NomineenameController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Nominee’s Name',
                            hintText: 'Enter the Nominee’s Name',
                            suffixIcon: IconButton(
                              onPressed: () => _NomineenameController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),
                  SizedBox(height: 13.0),

                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Age',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [

                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.number,
                          controller: _ageController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Age',
                            hintText: 'Enter the Nominee’s Age',
                            suffixIcon: IconButton(
                              onPressed: () => _ageController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),
                  SizedBox(height: 13.0),

                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Nominees`s relation',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [

                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.name,
                          controller: _relationController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Relation',
                            hintText: 'Enter the Nominee’s relation',
                            suffixIcon: IconButton(
                              onPressed: () => _relationController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),
                  SizedBox(height: 13.0),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}


//--------------------------------------------------------------------------------------
class Aadhar_num extends StatefulWidget {
  @override
  _Aadhar_numState createState() => _Aadhar_numState();
}

class _Aadhar_numState extends State<Aadhar_num> {
  final TextEditingController _controller1 = TextEditingController();
  final TextEditingController _controller2 = TextEditingController();
  final TextEditingController _controller3 = TextEditingController();

  late FocusNode _focusNode1;
  late FocusNode _focusNode2;
  late FocusNode _focusNode3;

  @override
  void initState() {
    super.initState();
    _focusNode1 = FocusNode();
    _focusNode2 = FocusNode();
    _focusNode3 = FocusNode();

    _focusNode1.addListener(() {
      if (!_focusNode1.hasFocus && _controller1.text.length == 4) {
        FocusScope.of(context).requestFocus(_focusNode2);
      }
    });

    _focusNode2.addListener(() {
      if (!_focusNode2.hasFocus && _controller2.text.length == 4) {
        FocusScope.of(context).requestFocus(_focusNode3);
      }
    });

    _focusNode3.addListener(() {
      if (!_focusNode3.hasFocus && _controller3.text.length == 4) {
        // Do something when all fields are filled
      }
    });
  }

  @override
  void dispose() {
    _controller1.dispose();
    _controller2.dispose();
    _controller3.dispose();
    _focusNode1.dispose();
    _focusNode2.dispose();
    _focusNode3.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: TextFormField(
                controller: _controller1,
                focusNode: _focusNode1,
                maxLength: 4,
                keyboardType: TextInputType.number,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.digitsOnly
                ],
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  counterText: '',
                ),
                onChanged: (value) {
                  if (value.length == 4) {
                    FocusScope.of(context).requestFocus(_focusNode2);
                  }
                },
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: TextFormField(
                controller: _controller2,
                focusNode: _focusNode2,
                maxLength: 4,
                keyboardType: TextInputType.number,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.digitsOnly
                ],
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  counterText: '',
                ),
                onChanged: (value) {
                  if (value.length == 4) {
                    FocusScope.of(context).requestFocus(_focusNode3);
                  }
                },
              ),
            ),
            SizedBox(width: 10),
            Expanded(
              child: TextFormField(
                controller: _controller3,
                focusNode: _focusNode3,
                maxLength: 4,
                keyboardType: TextInputType.number,
                inputFormatters: <TextInputFormatter>[
                  FilteringTextInputFormatter.digitsOnly
                ],
                decoration: InputDecoration(
                  border: OutlineInputBorder(),
                  counterText: '',
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
