import 'package:flutter/material.dart';
import 'package:swayam/screens/shg/shg_management/shgdetails.dart';
import 'editMemDeets_inList.dart';

class memberdetailsInMemList extends StatefulWidget {
  const memberdetailsInMemList({Key? key}) : super(key: key);

  @override
  State<memberdetailsInMemList> createState() => _memberdetailsInMemListState();
}

class _memberdetailsInMemListState extends State<memberdetailsInMemList> {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Color(0xffa69be0)),
        title: Text(
          "Gayatri Devi",
          style: TextStyle(
            fontFamily: "Montserrat",
            fontSize: 17,
            letterSpacing: 1.2,
            color: Color(0xff6750A4),
          ),
        ),
        //title: const Text("Home Screen"),
        backgroundColor: Colors.purple[50],
        leading: IconButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => shgdetails(),
                  ));
              //print('A new member added to the group');
            },
            icon: Icon(Icons.arrow_back)),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(45.0),
              child: Container(
                decoration: BoxDecoration(
                    border: Border.all(width: 15, color: Color(0xffCCBBE7)),
                    borderRadius: BorderRadius.circular(110)),
                child: CircleAvatar(
                  backgroundImage: NetworkImage(
                      'https://images.pexels.com/photos/3934783/pexels-photo-3934783.jpeg?auto=compress&cs=tinysrgb&w=600'), // or AssetImage if local image
                  radius: 70.0,
                  backgroundColor: Colors.grey,
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Basic Info',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),
                  Text(
                    'Full Name: ',
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    'Gayatri Devi',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  SizedBox(height: 13.0),
                  Text(
                    'Mobile Number: ',
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    '9100861969',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  SizedBox(height: 13.0),
                  Text(
                    'SHG Role: ',
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    'President',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  SizedBox(height: 13.0),
                  Text(
                    'Email Address: ',
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    '-',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Personal Info',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),

                  Text(
                    "Husbands/Father's Name ",
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    'Dinesh',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  SizedBox(height: 13.0),

                  Text(
                    "Aadhar Card Number",
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    '1234-5678-9012',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  SizedBox(height: 13.0),

                  Text(
                    'Has Bookkeeper',
                    style: TextStyle(fontSize: 12.0,color: Colors.black54),),
                  Row(
                    children: [
                      Text("Year Only"),
                      Padding(
                        padding: const EdgeInsets.only(top: 5.0, left: 25),
                        child: yearOnlySlider(),
                      ),
                    ],
                  ),
                  SizedBox(height: 13.0),

                  Text(
                    "Date",
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    '12-03-1976',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  SizedBox(height: 13.0),

                  Text(
                    "Age",
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    '47',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  SizedBox(height: 13.0),
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Nominee Details',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),

                  Text(
                    "Name ",
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    'Krishna Devi',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  SizedBox(height: 13.0),

                  Text(
                    "Age",
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    '20',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  SizedBox(height: 13.0),

                  Text(
                    "Relation",
                    style: TextStyle(fontSize: 12.0, color: Colors.black54),
                  ),
                  Text(
                    'Daughter',
                    style: TextStyle(
                      fontSize: 14.0,
                    ),
                  ),
                  SizedBox(height: 13.0),


                ],
              ),
            ),

          ],
        ),
      ),
      floatingActionButton: InkWell(
        onTap: () {
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => MemListEditDetails(),
              ));
        },
        child: Container(
          width: 50.0,
          height: 50.0,
          decoration: BoxDecoration(
            color: Color(0xffEADDFF),
            borderRadius: BorderRadius.circular(8.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey,
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Icon(Icons.mode_edit_outline_outlined),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}

//-------------------------------------------------------------
class yearOnlySlider extends StatefulWidget {
  const yearOnlySlider({Key? key}) : super(key: key);

  @override
  State<yearOnlySlider> createState() => _yearOnlySliderState();
}
class _yearOnlySliderState extends State<yearOnlySlider> {
  bool _sliderValue = true;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _sliderValue = !_sliderValue; // toggle slider value
        });
      },
      child: Container(
        width: 50.0,
        height: 30.0,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          color: _sliderValue ? Colors.purple : Colors.grey,
        ),
        child: Padding(
          padding: const EdgeInsets.all(4.0),
          child: Align(
            alignment: _sliderValue
                ? Alignment.centerRight
                : Alignment.centerLeft,
            child: Container(
              width: 22.0,
              height: 22.0,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}