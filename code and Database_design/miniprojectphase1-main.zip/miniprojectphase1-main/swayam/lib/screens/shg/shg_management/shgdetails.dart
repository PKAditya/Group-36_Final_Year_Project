import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:swayam/providers/group_provider.dart';
import 'package:swayam/screens/shg/shg_management/add_user_list.dart';
import '../../../models/group.dart';
import '../../../models/user.dart';
import 'deets_member_list.dart';
import 'shgManagement.dart';
import 'edit_shg_details.dart';
import 'add_shg.dart';

class shgdetails extends StatefulWidget {
  const shgdetails({Key? key}) : super(key: key);

  @override
  State<shgdetails> createState() => _shgdetailsState();
}

class _shgdetailsState extends State<shgdetails> {
  final List<Tab> tabs = [
    Tab(text: 'Group Details'),
    Tab(text: 'Member List'),
  ];
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: tabs.length,
      child: Scaffold(
        appBar: AppBar(
          iconTheme: IconThemeData(color: Color(0xffa69be0)),
          title: Text(
            "AmritaSree",
            style: TextStyle(
              fontFamily: "Montserrat",
              fontSize: 17,
              letterSpacing: 1.2,
              color: Color(0xff6750A4),
            ),
          ),
          //title: const Text("Home Screen"),
          backgroundColor: Colors.purple[50],
          leading: IconButton(
              onPressed: () {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => shgManagement(),
                    ));
                //print('A new member added to the group');
              },
              icon: Icon(Icons.arrow_back)),
        ),
        body: Column(
          children: [
            Container(
              color: Color(0xffFCFCFC), // set the TabBar background color
              child: TabBar(
                tabs: tabs,
                indicatorColor: Colors.purple, // set the TabBar indicator color
                labelColor: Colors.black,
                unselectedLabelColor: Colors.black.withOpacity(0.4),
              ),
            ),
            Expanded(
              child: TabBarView(
                children: [
                  GroupDetailsScreen(),
                  MemberListScreen(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
  }



class GroupDetailsScreen extends StatefulWidget {
  const GroupDetailsScreen({Key? key}) : super(key: key);

  @override
  State<GroupDetailsScreen> createState() => _GroupDetailsScreenState();
}

class _GroupDetailsScreenState extends State<GroupDetailsScreen> {
  bool _sliderValue = true;
  Group group=Group();
  void initState() {
    super.initState();
    // group = Group();
    // group = Provider.of<GroupProvider>(context, listen: false).group;
  }
  Future<void> _refresh() async {
    await Provider.of<GroupProvider>(context, listen: false).fetchGroup(context);
  }
  Future<void> fetchGroup() async {
    await _refresh();
    group=await Provider.of<GroupProvider>(context, listen: false).getGroup();
  }
  @override
  Widget build(BuildContext context) {
  GroupProvider groupProvider = Provider.of<GroupProvider>(context);
    // fetchGroup();
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Color(0xffFCFCFC),
      body: SingleChildScrollView(
        child: Container(

          child: (groupProvider.isLoading == true) ? Center(child: CircularProgressIndicator()) :
          Column(
            children: [
              Container(

                margin: EdgeInsets.all(20.0),
                padding: EdgeInsets.all(20.0),
                width: size.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Color(0xffFCFCFC),
                  border: Border.all(
                    color: Colors.grey,
                    width: 1.0,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'General Info',
                      style: TextStyle(
                        fontSize: 22.0,
                        fontWeight: FontWeight.bold,
                        fontFamily: "Montserrat",
                      ),
                    ),
                    SizedBox(height: 25.0),
                    Text(
                      'SHG Name',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                    Text(
                      '${groupProvider.group.groupName}',
                      style: TextStyle(
                        fontSize: 14.0,
                      ),
                    ),
                    SizedBox(height: 13.0),
                    Text(
                      'Registration Number',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                    Text(
                      '${groupProvider.group.sg_RegNo}',
                      style: TextStyle(
                        fontSize: 14.0,
                      ),
                    ),
                    SizedBox(height: 13.0),
                    Text(
                      'Legacy Affiliation Number',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                    Text(
                      '${groupProvider.group.old_RegNo}',
                      style: TextStyle(
                        fontSize: 14.0,
                      ),
                    ),
                    SizedBox(height: 13.0),
                    Text(
                      'Location',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                    Text(
                      '${groupProvider.group.town} ${groupProvider.group.district} ${groupProvider.group.pinCode}',
                      style: TextStyle(
                        fontSize: 14.0,
                      ),
                    ),
                    SizedBox(height: 25.0),
                    Text(
                      'Local Body Details',
                      style: TextStyle(fontSize: 14.0, color: Colors.black54),
                    ),
                    SizedBox(height: 13.0),
                    Text(
                      'Block',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                    Text(

                    '${groupProvider.group.town}',
                      style: TextStyle(
                        fontSize: 14.0,
                      ),
                    ),
                    SizedBox(height: 13.0),
                    Text(
                      'Panchayat',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                    Text(
                      '${groupProvider.group.panchayat}',
                      style: TextStyle(
                        fontSize: 14.0,
                      ),
                    ),
                    SizedBox(height: 13.0),
                    Text(
                      'Formation Date',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                    Text(
                      ' ${groupProvider.group.dof}',
                      style: TextStyle(
                        fontSize: 14.0,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.all(20.0),
                padding: EdgeInsets.all(20.0),
                width: size.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Color(0xffFCFCFC),
                  border: Border.all(
                    color: Colors.grey,
                    width: 1.0,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Administration',
                      style: TextStyle(
                        fontSize: 22.0,
                        fontWeight: FontWeight.bold,
                        fontFamily: "Montserrat",
                      ),
                    ),
                    SizedBox(height: 25.0),
                    Text(
                      'President',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                    Text(
                      (groupProvider.isAdminsLoading == false) ?
                      '${groupProvider.presedent.firstname}':"Loading...",
                      style: TextStyle(
                        fontSize: 14.0,
                      ),
                    ),
                    SizedBox(height: 25.0),
                    Text(
                      'Secretary',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                    Text(
                      (groupProvider.isAdminsLoading == false) ?
                      '${groupProvider.secretary.firstname}':"Loading...",
                      style: TextStyle(
                        fontSize: 14.0,
                      ),
                    ),
                    SizedBox(height: 25.0),
                    Text(
                      'Treasurer',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                    Text(

                      (groupProvider.isAdminsLoading == false) ?
                      '${groupProvider.treasurer.firstname}':"Loading...",
                      style: TextStyle(
                        fontSize: 14.0,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                margin: EdgeInsets.all(20.0),
                padding: EdgeInsets.all(20.0),
                width: size.width,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  color: Color(0xffFCFCFC),
                  border: Border.all(
                    color: Colors.grey,
                    width: 1.0,
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Group Settings',
                      style: TextStyle(
                        fontSize: 22.0,
                        fontWeight: FontWeight.bold,
                        fontFamily: "Montserrat",
                      ),
                    ),
                    SizedBox(height: 25.0),
                    Text(
                      'Meeting Frequency',
                      style: TextStyle(fontSize: 12.0,color: Colors.black54),
                    ),
                    Text("Every 2 Weeks",style: TextStyle(fontSize: 15.0),),

                    SizedBox(height: 16.0),
                    Text(
                      'Regular Deposit Amount',
                      style: TextStyle(fontSize: 12.0,color: Colors.black54),
                    ),
                    Text("Rs. 500.00",style: TextStyle(fontSize: 15.0),),

                    SizedBox(height: 16.0),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          children: [Text(
                            'Late Fees (Per Day)',
                            style: TextStyle(fontSize: 12.0,color: Colors.black54),
                          ),
                            Text("Rs. 10.00",style: TextStyle(fontSize: 15.0),),],
                        ),

                        Column(
                          children: [Text(
                            'Late Fees (Per Month)',
                            style: TextStyle(fontSize: 12.0,color: Colors.black54),
                          ),
                            Text("Rs. 250.00",style: TextStyle(fontSize: 15.0),),],
                        ),
                      ],
                    ),

                    SizedBox(height: 16.0),
                    Text(
                      'Has Bookkeeper',
                      style: TextStyle(fontSize: 12.0,color: Colors.black54),),
                    Padding(
                      padding: const EdgeInsets.only(top: 5.0),
                      child: GestureDetector(
                        onTap: () {
                          setState(() {
                            _sliderValue = !_sliderValue; // toggle slider value
                          });
                        },
                        child: Container(
                          width: 50.0,
                          height: 30.0,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(16.0),
                            color: _sliderValue ? Colors.purple : Colors.grey,
                          ),
                          child: Padding(
                            padding: const EdgeInsets.all(4.0),
                            child: Align(
                              alignment: _sliderValue
                                  ? Alignment.centerRight
                                  : Alignment.centerLeft,
                              child: Container(
                                width: 22.0,
                                height: 22.0,
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),


                    SizedBox(height: 16.0),
                    Text(
                      'Bookkeeper Fee',
                      style: TextStyle(fontSize: 12.0,color: Colors.black54),
                    ),
                    SizedBox(height: 8.0),
                    Text("Rs. 500.00",style: TextStyle(fontSize: 15.0),),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: InkWell(
        onTap: () {
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => SHGEdits(),
              ));
        },
        child: Container(
          width: 50.0,
          height: 50.0,
          decoration: BoxDecoration(
            color: Color(0xffEADDFF),
            borderRadius: BorderRadius.circular(8.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey,
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Icon(Icons.mode_edit_outline_outlined),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}



class MemberListScreen extends StatefulWidget {
  const MemberListScreen({Key? key}) : super(key: key);

  @override
  State<MemberListScreen> createState() => _MemberListScreenState();
}

class _MemberListScreenState extends State<MemberListScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child:
            list_mem(),

      ),
      floatingActionButton: InkWell(
        onTap: () {
          Navigator.pushReplacement(
              context,
              MaterialPageRoute(
                builder: (context) => AddMemListDetails(),
              ));
        },
        child: Container(
          width: 50.0,
          height: 50.0,
          decoration: BoxDecoration(
            color: Color(0xffEADDFF),
            borderRadius: BorderRadius.circular(8.0),
            boxShadow: [
              BoxShadow(
                color: Colors.grey,
                spreadRadius: 2,
                blurRadius: 5,
                offset: Offset(0, 3),
              ),
            ],
          ),
          child: Icon(Icons.add),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endFloat,
    );
  }
}




//--------------------------------------------------------------------------------------------------------
class list_mem extends StatefulWidget {
  const list_mem({Key? key}) : super(key: key);

  @override
  State<list_mem> createState() => _list_memState();
}

class _list_memState extends State<list_mem> {

  @override
  Widget build(BuildContext context) {
    GroupProvider groupProvider = Provider.of<GroupProvider>(context);
    List<User> users=(groupProvider.isLoading == false) ? groupProvider.getUsers():[];

    return (groupProvider.isLoading == true) ? Padding(
      padding: const EdgeInsets.all(15.0),
      child: Center(child: CircularProgressIndicator()),
    ):
    ListView.builder(itemCount:users.length ,itemBuilder:(context, index){
      User user =users[index];
      return Card(
        child: ListTile(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30.0),
          ),
          title: Text(user.firstname),
          subtitle: Row(
            children: [
              Text(user.role.toString()),
              SizedBox(width: 10,),
        Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Row(
                                        children: [
                                          Icon(Icons.phone,
                                              size: 18,
                                              color: Colors.green.shade600,
                                              shadows: [Shadow(color: Colors.black)]),
                                          SizedBox(width: 8.0),
                                          Text(
                                            '${user.phoneNumber}',
                                            style: TextStyle(
                                              fontFamily: 'Prompt',
                                              fontSize: 13.0,
                                            ),
                                          ),

                                        ],
                                      ),
                                    ),
            ],
          ),
          leading: CircleAvatar(
            backgroundImage: NetworkImage('https://images.pexels.com/photos/3934783/pexels-photo-3934783.jpeg?auto=compress&cs=tinysrgb&w=600'),
          ),

          trailing: Icon(Icons.arrow_forward_rounded),
          onTap: ()  {
            // print("mg");
            // Navigator.push(context,
            //     MaterialPageRoute(builder:(context) => GroupDetails(group)));
          },
        ),
      );
    });
    //   SingleChildScrollView(
    //   child: Container(
    //     padding: EdgeInsets.symmetric(vertical: 10),
    //     margin: EdgeInsets.symmetric(horizontal: 20,vertical: 30),
    //     child: Column(
    //       children: [
    //         InkWell(
    //           onTap: () {
    //             Navigator.pushReplacement(
    //                 context,
    //                 MaterialPageRoute(
    //                   builder: (context) => memberdetailsInMemList(),
    //                 ));
    //           },
    //           child: Container(
    //             decoration: BoxDecoration(color: Color(0xffFFFBFE),),
    //             child: Column(
    //               children: [
    //                 Container(
    //                   //margin: EdgeInsets.symmetric(),
    //                   decoration: BoxDecoration(
    //                     //color: Color(0xffFFFBFE),
    //                     //border: Border.all(color: Colors.grey),
    //                     //borderRadius: BorderRadius.circular(8.0),
    //
    //                   ),
    //                   child: Padding(
    //                     padding: const EdgeInsets.all(16.0),
    //                     child: Row(
    //                       children: [
    //                         Expanded(
    //                           child: Column(
    //                             children: [
    //                               Row(
    //                                 crossAxisAlignment: CrossAxisAlignment.start,
    //                                 children: [
    //                                   CircleAvatar(
    //                                     backgroundImage: NetworkImage(
    //                                         'https://images.pexels.com/photos/3934783/pexels-photo-3934783.jpeg?auto=compress&cs=tinysrgb&w=600'), // or AssetImage if local image
    //                                     radius: 30.0,
    //                                     backgroundColor: Colors.grey,
    //                                   ),
    //                                   SizedBox(width: 16.0),
    //                                   Expanded(
    //                                     child: Column(
    //                                       crossAxisAlignment: CrossAxisAlignment.start,
    //                                       children: [
    //                                         Text(
    //                                           'Gayatri Devi',
    //                                           style: TextStyle(
    //                                             fontFamily: 'Prompt',
    //                                             fontWeight: FontWeight.bold,
    //                                             fontSize: 16.0,
    //                                           ),
    //                                         ),
    //                                         SizedBox(height: 3.0),
    //                                         Text(
    //                                           'President',
    //                                           style: TextStyle(
    //                                             fontFamily: 'Prompt',
    //                                             fontSize: 12.0,
    //                                           ),
    //                                         ),
    //
    //                                         SizedBox(height: 8.0),
    //                                       ],
    //                                     ),
    //                                   ),
    //                                   SizedBox(width: 16.0),
    //
    //
    //                                 ],
    //                               ),
    //                           Padding(
    //                             padding: const EdgeInsets.all(12.0),
    //                             child: Row(
    //                               children: [
    //                                 Icon(Icons.phone,
    //                                     size: 18,
    //                                     color: Colors.green.shade600,
    //                                     shadows: [Shadow(color: Colors.black)]),
    //                                 SizedBox(width: 8.0),
    //                                 Text(
    //                                   '9100861969',
    //                                   style: TextStyle(
    //                                     fontFamily: 'Prompt',
    //                                     fontSize: 13.0,
    //                                   ),
    //                                 ),
    //
    //                               ],
    //                             ),
    //                           ),
    //                             ],
    //                           ),
    //                         ),
    //                         Column(mainAxisAlignment: MainAxisAlignment.center,crossAxisAlignment: CrossAxisAlignment.center,
    //                           children: [
    //                             Icon(Icons.arrow_right_outlined),
    //                           ],
    //                         ),
    //                       ],
    //                     ),
    //                   ),
    //                 ),
    //                 Container(
    //                   child: SizedBox(
    //                     width: 300,
    //                     height: 5,
    //                     child: Divider(
    //                       color: Colors.grey,
    //                     ),
    //                   ),
    //                 ),
    //               ],
    //             ),
    //           ),
    //         ),
    //       ],
    //     ),
    //   ),
    // );
  }
}