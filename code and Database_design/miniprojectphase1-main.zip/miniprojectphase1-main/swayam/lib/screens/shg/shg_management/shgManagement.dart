import 'package:flutter/material.dart';
import 'package:swayam/screens/homescreen/homescreen.dart';
import 'package:swayam/screens/shg/shg_management/add_shg.dart';
import 'shgdetails.dart';


class shgManagement extends StatefulWidget {
  const shgManagement({Key? key}) : super(key: key);

  @override
  State<shgManagement> createState() => _shgManagementState();
}

class _shgManagementState extends State<shgManagement> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffFCFCFC),
      appBar: AppBar(
        iconTheme: IconThemeData(color: Color(0xff6750A4)),
        actions: [
          IconButton(
              icon: Icon(Icons.add, size: 30),
              onPressed: () {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => addNewSHG(),
                    ));
              }),
          Padding(
            padding: EdgeInsets.only(right: 20),
          ),
        ],
        elevation: 0,
        leading: IconButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => homescreen(),
                  ));
              //print('A new member added to the group');
            },
            icon: Icon(Icons.arrow_back)),
        automaticallyImplyLeading: false,
        centerTitle: true,
        title: Text(
          "SHG MANAGEMENT",
          style: TextStyle(
            fontFamily: "Montserrat",
            fontSize: 17,
            letterSpacing: 1.2,
            color: Color(0xff6750A4),
          ),
        ),
        //title: const Text("Home Screen"),
        backgroundColor: Color(0xffFCFCFC),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            shgBox(),
          ],
        ),
      ),
    );
  }
}


//widgets used--------------------------------------------


class shgBox extends StatefulWidget {
  const shgBox({Key? key}) : super(key: key);

  @override
  State<shgBox> createState() => _shgBoxState();
}

class _shgBoxState extends State<shgBox> {
  bool _sliderValue = true;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 10),
        margin: EdgeInsets.symmetric(horizontal: 20,vertical: 30),
        child: Column(
          children: [
            InkWell(
              onTap: () {
                Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => shgdetails(),
                    ));
              },
              child: Container(
                decoration: BoxDecoration(color: Color(0xffFFFBFE),),
                child: Column(
                  children: [
                    Container(
                      //margin: EdgeInsets.symmetric(),
                      decoration: BoxDecoration(
                        //color: Color(0xffFFFBFE),
                        //border: Border.all(color: Colors.grey),
                        //borderRadius: BorderRadius.circular(8.0),

                      ),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [

                                Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    GestureDetector(
                                      onTap: () {
                                        if (_sliderValue) { // show dialog only if slider is currently off
                                          showDialog(
                                            context: context,
                                            builder: (BuildContext context) {
                                              return AlertDialog(
                                                shape: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),
                                                title: Text('DELETE SHG?',style: TextStyle(fontFamily: "Montserrat",color: Color(0xff6750A4),fontSize: 16),textAlign: TextAlign.center),
                                                content: Text(
                                                  'This SHG does not have any dependencies and can be deleted completely. Do you want to delete the SHG from system or just disable it?',
                                                  style: TextStyle(fontFamily: 'Prompt',fontSize: 11.5),
                                                ),
                                                actions: <Widget>[
                                                  TextButton(
                                                    child: Text('Delete SHG',style: TextStyle(fontFamily: 'Prompt')),
                                                    onPressed: () {
                                                      Navigator.of(context).pop();
                                                    },
                                                  ),
                                                  TextButton(
                                                    child: Container(
                                                      padding: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                                                      decoration: BoxDecoration(
                                                        color: Colors.purple,
                                                        borderRadius: BorderRadius.circular(8.0),
                                                      ),
                                                      child: Text(
                                                        'Disable SHG',
                                                        style: TextStyle(
                                                          fontFamily: 'Prompt',
                                                          color: Colors.white,
                                                          fontWeight: FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                    onPressed: () {
                                                      setState(() {
                                                        _sliderValue = false; // turn off the slider
                                                      });
                                                      Navigator.of(context).pop();
                                                    },
                                                  ),
                                                ],
                                              );
                                            },
                                          );
                                        } else {
                                          setState(() {
                                            _sliderValue = true ; // turn on the slider again
                                          });
                                        }
                                      },
                                      child: Container(
                                        width: 50.0,
                                        height: 30.0,
                                        decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(16.0),
                                          color: _sliderValue ? Colors.purple : Colors.grey,
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: Align(
                                            alignment: _sliderValue
                                                ? Alignment.centerRight
                                                : Alignment.centerLeft,
                                            child: Container(
                                              width: 22.0,
                                              height: 22.0,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: Colors.white,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(width: 16.0),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'AmritaSree',
                                        style: TextStyle(
                                          fontFamily: 'Prompt',
                                          fontWeight: FontWeight.bold,
                                          fontSize: 16.0,
                                        ),
                                      ),
                                      SizedBox(height: 3.0),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(
                                            'Ira Kuttanad, Alappuzha',
                                            style: TextStyle(
                                              fontFamily: 'Prompt',
                                              fontSize: 12.0,
                                            ),
                                          ),
                                          Icon(Icons.arrow_right_outlined),
                                        ],
                                      ),
                                      SizedBox(height: 3.0),
                                      Text(
                                        'Kerala',
                                        style: TextStyle(
                                          fontFamily: 'Prompt',
                                          fontSize: 12.0,
                                        ),
                                      ),
                                      SizedBox(height: 8.0),
                                    ],
                                  ),
                                ),
                                //SizedBox(width: 16.0),


                              ],
                            ),

                          ],
                        ),
                      ),
                    ),
                    Container(
                      child: SizedBox(

                        height: 5,
                        child: Divider(
                          color: Colors.grey,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),

          ],
        ),
      ),
    );
  }
}

