import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:swayam/screens/shg/shg_management/shgManagement.dart';
import 'shgdetails.dart';


class addNewSHG extends StatefulWidget {
  const addNewSHG({Key? key}) : super(key: key);

  @override
  State<addNewSHG> createState() => _addNewSHGState();
}

class _addNewSHGState extends State<addNewSHG> {
  final TextEditingController _SHGnameController = TextEditingController();
  final TextEditingController _affNumberController = TextEditingController();
  final TextEditingController _RDAnumberController = TextEditingController();
  final TextEditingController _LateFeeDayController = TextEditingController();
  final TextEditingController _LateFeeMonthController = TextEditingController();
  final TextEditingController _BookKeerperFeeController = TextEditingController();
  final TextEditingController _percentController = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  void showLocationSelectionDialog(BuildContext context) {
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Edit Location"),
      shape: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),

      content: Form(
        key: _formKey,
        child: SizedBox(height: 300,
            child: setLocationWidget()),
      ),
      actions: [
        TextButton(
          child: Text("Cancel"),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        ElevatedButton(
          child: Text("Save"),
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              Navigator.of(context).pop();
            }
          },
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all<Color>(Colors.purple[200]!),
            shape: MaterialStateProperty.all<RoundedRectangleBorder>(
              RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18.0),
              ),
            ),
          ),
        ),
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }
  void showLocalBodySelectionDialog(BuildContext context) {
    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Edit Local Body Details"),
      shape: OutlineInputBorder(borderRadius: BorderRadius.circular(20)),

      content: Form(
        key: _formKey,
        child: SizedBox(height: 150,child: setLocalBodyWidget()),
      ),
      actions: [
        TextButton(
          child: Text("Cancel"),
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
        ElevatedButton(
          child: Text("Save"),
          onPressed: () {
            if (_formKey.currentState!.validate()) {
              Navigator.of(context).pop();
            }
          },
          style: ButtonStyle(
            backgroundColor: MaterialStateProperty.all<Color>(Colors.purple[200]!),
            shape: MaterialStateProperty.all<RoundedRectangleBorder>(
              RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(18.0),
              ),
            ),
          ),
        ),
      ],
    );

    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );
  }


  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(color: Color(0xff6750A4)),
        title: Text(
          "ADD SHG",
          style: TextStyle(
            fontFamily: "Montserrat",
            fontSize: 17,
            letterSpacing: 1.2,
            color: Color(0xff6750A4),
          ),
        ),
        //title: const Text("Home Screen"),
        backgroundColor: Colors.purple[50],
        leading: IconButton(
            onPressed: () {
              Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(
                    builder: (context) => shgManagement(),
                  ));
              //print('A new member added to the group');
            },
            icon: Icon(Icons.arrow_back)),
        actions: [
          IconButton(
            icon: Text(
              "Save",
              style: TextStyle(color: Color(0xff6750A4)),
            ),
            onPressed: () {
              showModalBottomSheet(
                shape: OutlineInputBorder(borderRadius: BorderRadius.only(topRight: Radius.circular(20),topLeft: Radius.circular(20))),
                context: context,
                builder: (BuildContext context) {
                  return Container(
                    decoration: BoxDecoration(
                      //color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(100),
                        topRight: Radius.circular(100),
                      ),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(100)),
                          child: Text(
                            "EXIT WITHOUT SAVING?",
                            style: TextStyle(
                              fontSize: 15,
                              color: Color(0xff6750A4),
                              letterSpacing: 1.2,
                              fontFamily: "Montserrat",
                            ),
                            textAlign: TextAlign.left,
                          ),
                          padding: EdgeInsets.symmetric(vertical: 15),
                        ),
                        SizedBox(
                          width: 300,
                          height: 15,
                          child: Divider(
                            color: Colors.black,
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(vertical: 30,horizontal: 20),
                          child: Text(
                            'You have some unsaved changes. Do you want to save them?',
                            style:
                            TextStyle(fontFamily: 'Prompt', fontSize: 11.5),
                          ),
                        ),
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(mainAxisAlignment: MainAxisAlignment.end,
                            children: [TextButton(
                              child: Text('Cancel',
                                  style: TextStyle(fontFamily: 'Prompt')),
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                            ),
                              TextButton(
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                      horizontal: 16.0, vertical: 8.0),
                                  decoration: BoxDecoration(
                                    color: Colors.purple,
                                    borderRadius: BorderRadius.circular(8.0),
                                  ),
                                  child: Text(
                                    'Yes',
                                    style: TextStyle(
                                      fontFamily: 'Prompt',
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                                onPressed: () {
                                  //showUserEditedDialog(context);
                                  Navigator.pushReplacement(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => shgManagement(),
                                      ));

                                },
                              ),],
                          ),
                        ),
                      ],
                    ),
                  );
                },
              );
            },
          ),
          Padding(
            padding: EdgeInsets.only(right: 20),
          ),
        ],
      ),
      backgroundColor: Color(0xffFCFCFC),
      body: SingleChildScrollView(
        child: Column(
          children: [

            //General Info
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'General Info',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  SizedBox(height: 25.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'SHG Name: ',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.name,
                          controller: _SHGnameController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'SHG Name',
                            hintText: 'Enter the SHG Name',
                            suffixIcon: IconButton(
                              onPressed: () => _SHGnameController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),

                  SizedBox(height: 16.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Legacy Affiliation Number',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          //keyboardType: TextInputType.none,
                          controller: _affNumberController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Legacy Affiliation Number',
                            hintText: 'Enter the Legacy Affiliation Number',
                            suffixIcon: IconButton(
                              onPressed: () => _affNumberController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),

                  SizedBox(height: 16.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Location',
                        style: TextStyle(fontSize: 12.0, color: Colors.black54),
                      ),
                      TextButton(
                          onPressed: () {showLocationSelectionDialog(context);},
                          child: Text(
                            "Edit",
                            style: TextStyle(
                                color: Color(0xff6750A4), fontSize: 12),
                          )),
                    ],
                  ),

                  SizedBox(height: 5.0),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'Local Body Details',
                        style: TextStyle(fontSize: 12.0, color: Colors.black54),
                      ),
                      TextButton(
                          onPressed: () {showLocalBodySelectionDialog(context);},
                          child: Text(
                            "Edit",
                            style: TextStyle(
                                color: Color(0xff6750A4), fontSize: 12),
                          )),
                    ],
                  ),

                  SizedBox(height: 16.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Date of fromation',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  date_of_formationWidget(),
                ],
              ),
            ),

            //Administration
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Administration',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),
                  administraionDropdwons(),
                ],
              ),
            ),

            //Group Settings
            Container(
              margin: EdgeInsets.all(20.0),
              padding: EdgeInsets.all(20.0),
              width: size.width,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Color(0xffFCFCFC),
                border: Border.all(
                  color: Colors.grey,
                  width: 1.0,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'General Info',
                    style: TextStyle(
                      fontSize: 22.0,
                      fontWeight: FontWeight.bold,
                      fontFamily: "Montserrat",
                    ),
                  ),

                  SizedBox(height: 25.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Meeting Frequency',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  meetingFrequencyDropdown(),

                  SizedBox(height: 16,),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Regular Deposit Amount',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.number,
                          controller: _RDAnumberController,

                          decoration: InputDecoration(
                            prefixIcon: Padding(
                              padding: const EdgeInsets.only(top: 8,right: 8,bottom: 8,left: 13),
                              child: Text("Rs.",style: TextStyle(fontSize: 15,fontFamily: 'Prompt')),
                            ),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Regular Deposit Amount',
                            hintText: 'Enter the Regular Deposit Amount',
                            suffixIcon: IconButton(
                              onPressed: () => _RDAnumberController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),

                  SizedBox(height: 16.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Late Fees (Per day)',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.number,
                          controller: _LateFeeDayController,

                          decoration: InputDecoration(
                            prefixIcon: Padding(
                              padding: const EdgeInsets.only(top: 8,right: 8,bottom: 8,left: 13),
                              child: Text("Rs.",style: TextStyle(fontSize: 15,fontFamily: 'Prompt')),
                            ),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Late Fees (per day)',
                            hintText: 'Enter per day Late Fees',
                            suffixIcon: IconButton(
                              onPressed: () => _LateFeeDayController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),

                  SizedBox(height: 16.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Late Fees (Per month)',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.number,
                          controller: _LateFeeMonthController,

                          decoration: InputDecoration(
                            prefixIcon: Padding(
                              padding: const EdgeInsets.only(top: 8,right: 8,bottom: 8,left: 13),
                              child: Text("Rs.",style: TextStyle(fontSize: 15,fontFamily: 'Prompt')),
                            ),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Late Fees (per month)',
                            hintText: 'Enter per month Late Fees',
                            suffixIcon: IconButton(
                              onPressed: () => _LateFeeMonthController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),

                  SizedBox(height: 16.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Default Interest Rate',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.number,
                          controller: _percentController,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Default Interest Rate',
                            hintText: 'Enter the Default Interest Rate',
                            suffixIcon: IconButton(
                              onPressed: () => _affNumberController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),

                  SizedBox(height: 16.0),
                  Text(
                    'Has Bookkeeper',
                    style: TextStyle(fontSize: 12.0,color: Colors.black54),),
                  Padding(
                    padding: const EdgeInsets.only(top: 5.0),
                    child: hasBookkeeperSlider(),
                  ),

                  SizedBox(height: 16.0),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 12.0),
                    child: Text(
                      'Bookkeeper Fee',
                      style: TextStyle(fontSize: 12.0, color: Colors.black54),
                    ),
                  ),
                  Row(
                    children: [
                      Expanded(
                        child: TextFormField(
                          keyboardType: TextInputType.number,
                          controller: _BookKeerperFeeController,

                          decoration: InputDecoration(
                            prefixIcon: Padding(
                              padding: const EdgeInsets.only(top: 8,right: 8,bottom: 8,left: 13),
                              child: Text("Rs.",style: TextStyle(fontSize: 15,fontFamily: 'Prompt')),
                            ),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12),),
                            labelText: 'Bookkeeper Fee',
                            hintText: 'Enter per the Bookkeeper Fee',
                            suffixIcon: IconButton(
                              onPressed: () => _BookKeerperFeeController.clear(),
                              icon: Icon(Icons.clear),
                            ),),),
                      ),
                    ],
                  ),


                ],
              ),

            ),
          ],
        ),
      ),
    );

  }
}



class setLocationWidget extends StatefulWidget {
  const setLocationWidget({Key? key}) : super(key: key);

  @override
  State<setLocationWidget> createState() => _setLocationWidgetState();
}
class _setLocationWidgetState extends State<setLocationWidget> {

  String state_dropdownValue = 'State';
  String district_dropdownValue = 'District';
  String subdistrict_dropdownValue = 'Sub-District';
  String Place_dropdownValue = 'Place';


  @override
  Widget build(BuildContext context) {

    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        InkWell(
          onTap: () {
            _showDropdownMenu(context, 'state');
          },
          child: Container(
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),border: Border.all(color: Colors.grey,width: 1)),
            padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            margin: EdgeInsets.symmetric(vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Text(
                      '$state_dropdownValue',
                      style: TextStyle(fontSize: 16.0),
                    ),
                  ),
                ),
                Icon(Icons.arrow_drop_down),

              ],
            ),
          ),
        ),
        InkWell(
          onTap: () {
            _showDropdownMenu(context, 'district');
          },
          child: Container(
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),border: Border.all(color: Colors.grey,width: 1)),
            padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            margin: EdgeInsets.symmetric(vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Text(
                      '$district_dropdownValue',
                      style: TextStyle(fontSize: 16.0),
                    ),
                  ),
                ),
                Icon(Icons.arrow_drop_down),

              ],
            ),
          ),
        ),
        InkWell(
          onTap: () {
            _showDropdownMenu(context, 'sub district');
          },
          child: Container(
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),border: Border.all(color: Colors.grey,width: 1)),
            padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            margin: EdgeInsets.symmetric(vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Text(
                      '$subdistrict_dropdownValue',
                      style: TextStyle(fontSize: 16.0),
                    ),
                  ),
                ),
                Icon(Icons.arrow_drop_down),

              ],
            ),
          ),
        ),
        InkWell(
          onTap: () {
            _showDropdownMenu(context, 'place');
          },
          child: Container(
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),border: Border.all(color: Colors.grey,width: 1)),
            padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            margin: EdgeInsets.symmetric(vertical: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 8.0),
                    child: Text(
                      '$Place_dropdownValue',
                      style: TextStyle(fontSize: 16.0),
                    ),
                  ),
                ),
                Icon(Icons.arrow_drop_down),

              ],
            ),
          ),
        ),
      ],

    );
  }

  void _showDropdownMenu(BuildContext context, String field) {
    Size size = MediaQuery.of(context).size;
    List<String> options = [];
    if (field == 'state') {
      options = ['Kerala', 'State Option 2', 'State Option 3'];
    } else if (field == 'district') {
      options = ['Kottayam', 'District Option 2', 'District Option 3'];
    } else if (field == 'sub district') {
      options = ['Changanaserry', 'Sub District Option 2', 'Sub District Option 3'];
    } else if (field == 'place') {
      options = ['Kanghaza', 'Place Option 2', 'Place Option 3'];
    }

    showMenu(
      context: context,
      position: RelativeRect.fromLTRB(0,0,0,0),
      items: options.map((String option) {
        return PopupMenuItem<String>(
          value: option,
          child: Text(option),
        );
      }).toList(),
    ).then((value) {
      if (value != null) {
        setState(() {
          if (field == 'state') {
            state_dropdownValue = value;
          } else if (field == 'district') {
            district_dropdownValue = value;
          } else if (field == 'sub district') {
            subdistrict_dropdownValue = value;
          } else if (field == 'place') {
            Place_dropdownValue = value;
          }
        });
      }
    });
  }
}


class setLocalBodyWidget extends StatefulWidget {
  const setLocalBodyWidget({Key? key}) : super(key: key);

  @override
  State<setLocalBodyWidget> createState() => _setLocalBodyWidgetState();
}
class _setLocalBodyWidgetState extends State<setLocalBodyWidget> {
  String panchayat_dropdownValue = 'Panchayat';
  String block_dropdownValue = 'Block';
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          InkWell(
            onTap:  () {
              _showDropdownMenu(context, 'panchayat');
            },
            child: Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),border: Border.all(color: Colors.grey,width: 1)),
              padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
              margin: EdgeInsets.symmetric(vertical: 10),
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Text(
                        '$panchayat_dropdownValue',
                        style: TextStyle(fontSize: 16.0),
                      ),
                    ),
                  ),
                  Icon(Icons.arrow_drop_down),

                ],
              ),
            ),
          ),

          InkWell(
            onTap: () {
              _showDropdownMenu(context, 'block');
            },
            child: Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),border: Border.all(color: Colors.grey,width: 1)),
              padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
              margin: EdgeInsets.symmetric(vertical: 10),
              child: Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Text(
                        '$block_dropdownValue',
                        style: TextStyle(fontSize: 16.0),
                      ),
                    ),
                  ),
                  Icon(Icons.arrow_drop_down),

                ],
              ),
            ),
          ),

        ],
      ),
    );
  }

  void _showDropdownMenu(BuildContext context, String field) {
    List<String> options = [];
    if (field == 'panchayat') {
      options = ['Allapad', 'panchayat Option 2', 'panchayat Option 3'];
    } else if (field == 'block') {
      options = ['Pudhikavvu', 'block Option 2', 'block Option 3'];
    }
    showMenu(
      context: context,
      position: RelativeRect.fromLTRB(0, 0, 0, 0),
      items: options.map((String option) {
        return PopupMenuItem<String>(
          value: option,
          child: Text(option),
        );
      }).toList(),
    ).then((value) {
      if (value != null) {
        setState(() {
          if (field == 'panchayat') {
            panchayat_dropdownValue = value;
          } else if (field == 'block') {
            block_dropdownValue = value;
          }
        });
      }
    });

  }
}


class administraionDropdwons extends StatefulWidget {
  const administraionDropdwons({Key? key}) : super(key: key);

  @override
  State<administraionDropdwons> createState() => _administraionDropdwonsState();
}
class _administraionDropdwonsState extends State<administraionDropdwons> {
  String pres_dropdownValue = '';
  String sec_dropdownValue = '';
  String tres_dropdownValue = '';

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 20),

      child: Column(
        //mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [

          InkWell(
            onTap: () {
              _showDropdownMenu(context, 'president');
            },
            child: Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),border: Border.all(color: Colors.grey,width: 1)),
              padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
              margin: EdgeInsets.symmetric(vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Text(
                        'President: $pres_dropdownValue',
                        style: TextStyle(fontSize: 16.0),
                      ),
                    ),
                  ),
                  Icon(Icons.arrow_drop_down),

                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              _showDropdownMenu(context, 'secretary');
            },
            child: Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),border: Border.all(color: Colors.grey,width: 1)),
              padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
              margin: EdgeInsets.symmetric(vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Text(
                        'Secretary: $sec_dropdownValue',
                        style: TextStyle(fontSize: 16.0),
                      ),
                    ),
                  ),
                  Icon(Icons.arrow_drop_down),

                ],
              ),
            ),
          ),
          InkWell(
            onTap: () {
              _showDropdownMenu(context, 'treasurer');
            },
            child: Container(
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(12),border: Border.all(color: Colors.grey,width: 1)),
              padding: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
              margin: EdgeInsets.symmetric(vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8.0),
                      child: Text(
                        'Treasurer: $tres_dropdownValue',
                        style: TextStyle(fontSize: 16.0),
                      ),
                    ),
                  ),
                  Icon(Icons.arrow_drop_down),

                ],
              ),
            ),
          ),
        ],
      ),

    );
  }

  void _showDropdownMenu(BuildContext context, String field) {
    final List<String> options = ['Amita Devi', 'Chandrika Kumari', 'Meera', 'Akanksha'];
    showMenu(
      context: context,
      position: RelativeRect.fromLTRB(0, 0, 0, 0),
      items: options.map((String option) {
        return PopupMenuItem<String>(
          value: option,
          child: Text(option),
        );
      }).toList(),
    ).then((value) {
      if (value != null) {
        setState(() {
          if (field == 'president') {
            pres_dropdownValue = value;
          } else if (field == 'secretary') {
            sec_dropdownValue = value;
          } else if (field == 'treasurer') {
            tres_dropdownValue = value;
          }
        });
      }
    });

  }
}

class date_of_formationWidget extends StatefulWidget {
  const date_of_formationWidget({Key? key}) : super(key: key);

  @override
  State<date_of_formationWidget> createState() => _date_of_formationWidgetState();
}
class _date_of_formationWidgetState extends State<date_of_formationWidget> {
  void pickDate() {
    showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1940),
      lastDate: DateTime.now(),).then((value) {
      setState(() {
        _dateTime= value!;
        hinttext= Text(DateFormat.yMMMd().format(_dateTime).toString());
      });
    });
  }
  DateTime _dateTime= DateTime.now();
  Text hinttext= Text(
    "Date of Formation",
    style: TextStyle(
      color: Colors.black54,
      fontSize: 14,
      fontFamily: 'GoogleSans',
      fontWeight: FontWeight.bold,
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(border: Border.all(color: Colors.grey,),borderRadius: BorderRadius.circular(12)),
      //margin: EdgeInsets.only(left: 55, top: 10),
      child: InkWell(
        onTap: () {
          pickDate();
        },
        child: Container(
          child: Row(
            children: [
              Container(
                height: 45,
                width: 185,
                //padding: EdgeInsets.only( right: 10),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.all(Radius.circular(25)),
                ),
                child: Center(child: Row(
                  children: [
                    Container(margin: EdgeInsets.only(left: 10,right: 30),child: Icon(Icons.calendar_today,color: Colors.grey),),
                    hinttext,
                  ],
                ),),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class meetingFrequencyDropdown extends StatefulWidget {
  const meetingFrequencyDropdown({Key? key}) : super(key: key);

  @override
  State<meetingFrequencyDropdown> createState() => _meetingFrequencyDropdownState();
}
class _meetingFrequencyDropdownState extends State<meetingFrequencyDropdown> {
  String Meeting_dropdownValue = 'Meeting Frequency';
  @override
  final roles = ["Every Week", "Every Two Weeks", "Every Month"];
  String? _selectedVal = "";

  Widget build(BuildContext context) {
    return Container(
      //height: 45,
      //margin: EdgeInsets.only(left: 55, right: 55, top: 10),
      // padding: EdgeInsets.only( right: 10),
      // decoration: BoxDecoration(
      //   color: Colors.white,
      //   borderRadius: BorderRadius.all(Radius.circular(25)),
      // ),
      child: DropdownButtonFormField(
        decoration: InputDecoration(

          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.all(Radius.circular(12)),
            borderSide: const BorderSide(color: Colors.grey),
          ),
        ),
        icon: const Icon(
          Icons.arrow_drop_down,

        ),
        hint: Text("Meeting Frequency",
            style: TextStyle(
              //color: Colors.black54,
              fontSize: 14,
              fontFamily: 'Prompt',
            )),
        items: roles
            .map(
              (e) => DropdownMenuItem(child: Text(e), value: e),
        )
            .toList(),
        onChanged: (val) {
          setState(() {
            _selectedVal = val as String;
          });
        },
      ),
    );
  }
}

class hasBookkeeperSlider extends StatefulWidget {
  const hasBookkeeperSlider({Key? key}) : super(key: key);

  @override
  State<hasBookkeeperSlider> createState() => _hasBookkeeperSliderState();
}
class _hasBookkeeperSliderState extends State<hasBookkeeperSlider> {
  bool _sliderValue = true;
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        setState(() {
          _sliderValue = !_sliderValue; // toggle slider value
        });
      },
      child: Container(
        width: 50.0,
        height: 30.0,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16.0),
          color: _sliderValue ? Colors.purple : Colors.grey,
        ),
        child: Padding(
          padding: const EdgeInsets.all(4.0),
          child: Align(
            alignment: _sliderValue
                ? Alignment.centerRight
                : Alignment.centerLeft,
            child: Container(
              width: 22.0,
              height: 22.0,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.white,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

