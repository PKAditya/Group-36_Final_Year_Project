import 'dart:convert';
import 'package:swayam/models/server_response.dart';
import 'package:swayam/common/constants.dart';
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';
import 'package:swayam/models/user.dart';

class GroupService {
  static const String PATH = "/group";
  static const String PATH_UPDATE = "/group/update";
  static const String PATH_SELF_REG = "/group/self-registration";


//=====================================================================================================================================

  Future<ServerResponse> createUser(User user, String authToken) async {
    User createdUser = User();
    ServerResponse serverResponse;
    String url;
    url = Constants.SERVER + PATH + ((authToken != "")
        ?( "?authToken=" + authToken) : "/self-registration");
    var userJson = user.toJson();
    print(url);
    userJson['password'] =
        sha512.convert(utf8.encode(userJson['password'])).toString();
    var body = json.encode(userJson);
    print(body);
    try {
      var response = await http.post(Uri.parse(url),  // checkkkkkkkkk
          body: body, headers: {"Content-Type": "application/json"});
      if (response.statusCode == 200) {
        print("point2");
        serverResponse = ServerResponse.fromJson(json.decode(response.body));
        if (serverResponse.ifSuccess()) {
          createdUser = User.fromJson(serverResponse.data);
        }
        serverResponse.result = createdUser;
      } else {
        serverResponse =
            ServerResponse(ServerResponse.FAILED, response.toString());
      }
    }
    catch (e) {
      serverResponse = ServerResponse(ServerResponse.FAILED, e.toString());
    }
    return serverResponse;
  }

//=====================================================================================================================================

  Future<ServerResponse> getGroup(String? authToken) async {
    String url = Constants.SERVER + PATH + "?authToken=" + authToken!;
    ServerResponse serverResponse = await fetchGroupFromServer(url);
    return serverResponse;
  }

//=====================================================================================================================================

  Future<ServerResponse> fetchGroupFromServer(String url) async {
    ServerResponse serverResponse;
    try {
      var response = await http.get(Uri.parse(url),headers: {"Content-Type": "application/json"});
      if (response.statusCode == 200) {
        serverResponse = ServerResponse.fromJson(json.decode(response.body));
        if (serverResponse.ifSuccess()) {
          List<int> compressed = [];
          var GroupData = serverResponse.data;

          serverResponse.result = GroupData;
        }
      } else {
        serverResponse =
            ServerResponse(ServerResponse.FAILED, response.toString());
      }
    }
    catch (e) {
      serverResponse = ServerResponse(ServerResponse.FAILED, e.toString());
    }
    return serverResponse;
  }

//=====================================================================================================================================

  Future<ServerResponse> getAllUsers(String? authToken) async {
    String url = Constants.SERVER + PATH +"/all"+"?authToken=" + authToken!;
    return fetchUsersFromServer(url);
  }
  //=====================================================================================================================================
  Future<ServerResponse> fetchUsersFromServer(String url) async {
    ServerResponse serverResponse;
    List<User> users;
    try {
      var response = await http.get(Uri.parse(url));
      if (response.statusCode == 200) {
        serverResponse = ServerResponse.fromJson(json.decode(response.body));
        if (serverResponse.ifSuccess()) {
          List<int> compressed = [];
          var userData = serverResponse.data;
          users = [];
          if (userData is List) {
            for (var i = 0; i < userData.length; i++) {
              var user = User.fromJson(userData[i]);
              users.add(user);
            }
          }
          serverResponse.result = users;
        }
      } else {
        serverResponse =
            ServerResponse(ServerResponse.FAILED, response.toString());
      }
    }
    catch (e) {
      serverResponse = ServerResponse(ServerResponse.FAILED, e.toString());
    }
    return serverResponse;
  }

//=====================================================================================================================================

  Future<ServerResponse> updateUser(User user, String? authToken) async {
    User updatedUser = User();
    ServerResponse serverResponse;
    String url = Constants.SERVER +
        PATH +
        "/" +
        user.username +
        "?authToken=" +
        authToken!;
    print(url);
    print(user.toJson());
    var body = json.encode(user.toJson());
    try {
      var response = await http.put(Uri.parse(url),
          body: body, headers: {"Content-Type": "application/json"});
      if (response.statusCode == 200) {
        serverResponse = ServerResponse.fromJson(json.decode(response.body));
        if (serverResponse.ifSuccess()) {
          updatedUser = User.fromJson(serverResponse.data);
        }
        serverResponse.result = updatedUser;
      } else {
        serverResponse =
            ServerResponse(ServerResponse.FAILED, response.toString());
      }
    }
    catch (e) {
      serverResponse = ServerResponse(ServerResponse.FAILED, e.toString());
    }
    return serverResponse;
  }

//=====================================================================================================================================

  Future<ServerResponse> deleteGroup(String groupId, String? authToken) async {
    ServerResponse serverResponse;
    String url = Constants.SERVER +
        PATH +
        "/" +
        groupId +
        "?authToken=" +
        authToken!;
    try {
      var response = await http.delete(Uri.parse(url));
      if (response.statusCode == 200) {
        serverResponse = ServerResponse.fromJson(json.decode(response.body));
      } else {
        serverResponse =
            ServerResponse(ServerResponse.FAILED, response.toString());
      }
    }
    catch (e) {
      serverResponse = ServerResponse(ServerResponse.FAILED, e.toString());
    }
    return serverResponse;
  }
}
