import 'dart:convert';
import 'package:swayam/common/constants.dart';
// import "package:swayam/models/user.dart";
import 'package:swayam/models/server_response.dart';
import 'package:http/http.dart' as http;
import 'package:crypto/crypto.dart';

class AuthService {
  static const String PATH_LOGIN = "/user/login";
  int serverTime = 0;
  int clientTimeWhenServerTime = 0;

  setServerTime(serverTime) {
    this.serverTime = serverTime;
    this.clientTimeWhenServerTime = DateTime.now().millisecondsSinceEpoch;
  }

  getServerTime(inputTime) {
    return inputTime - (this.clientTimeWhenServerTime - this.serverTime);
  }

  Future<ServerResponse> login(String userName, String password) async {
    ServerResponse serverResponse;
    String passHash = sha512.convert(utf8.encode(password)).toString();

    String url = Constants.SERVER + PATH_LOGIN;
    print(Uri.parse(url));
    Map data = {'username': userName, 'password': passHash};

    var body = json.encode(data);
    print(body);
    try {
      http.Response response = await http.post(Uri.parse(url),
          body: body, headers: {"Content-Type": "application/json"});
      print(response.statusCode);
      if (response.statusCode == 200) {
        serverResponse = ServerResponse.fromJson(json.decode(response.body));
        setServerTime(serverResponse.serverTime);
      } else {
        print("else condition in auth_service");
        serverResponse = ServerResponse.fromJson(json.decode(response.body));
      }
    }
    catch (error) {
      serverResponse =
          ServerResponse(ServerResponse.FAILED, "Unable to connect to server.");
    }
    return serverResponse;
  }
}