
import 'package:flutter/material.dart';
import 'package:swayam/models/group.dart';
import 'package:swayam/models/user.dart';
import 'package:swayam/models/server_response.dart';
import 'package:swayam/providers/auth_provider.dart';
import 'package:swayam/services/auth_service.dart';
import 'package:swayam/services/group_service.dart';
import 'package:provider/provider.dart';
import 'package:swayam/services/user_service.dart';

class GroupProvider with ChangeNotifier {
  List<User> _users = [];
  Group ? _group;
  Group get group => _group!;
  // List<User> get users => _users;
  GroupService _groupService = GroupService();
  // UserService _userService = UserService();
  // GroupService get groupService => _groupService;

  User ? _presedent;
  User ? _secretary;
  User ? _treasurer;

  User get presedent => _presedent!;
  User get secretary => _secretary!;
  User get treasurer => _treasurer!;


  bool isLoading = true;
  bool isAdminsLoading= true;



  GroupProvider (BuildContext  context) {
    helper(context);
    // return this;
  }

  // get _group => _group;
  // Future<ServerResponse> getGroups(BuildContext context) async {
  //   ServerResponse serverResponse;
  //   AuthService authService = Provider.of<AuthService>(context, listen: false);
  //   GroupService groupService =
  //       Provider.of<GroupService>(context, listen: false);
  //   serverResponse = await groupService.getGroups(authService);
  //   if (serverResponse.status == ServerResponse.SUCCESS) {
  //     _groups = serverResponse.data;
  //     notifyListeners();
  //   }
  //   return serverResponse;
  // }
  Future<void> helper(BuildContext context) async{
    // isLoading = true;
    await fetchGroup(context);
    await fetchUsers(context);
    isLoading = false;
    notifyListeners();
    await setAdmins(context);
  }
  Future<void> fetchGroup(BuildContext context) async{
    print("fetchGroup");
    AuthProvider authService = Provider.of<AuthProvider>(context, listen: false);
    ServerResponse serverResponse = await _groupService.getGroup(authService.authToken);
    if (serverResponse.status == ServerResponse.SUCCESS) {
      _group = Group.fromJson(serverResponse.data);
      print(_group!.groupName);
      notifyListeners();
    }
  }
  Future<void> fetchUsers(BuildContext context)async{
    AuthProvider authService = Provider.of<AuthProvider>(context, listen: false);
    ServerResponse serverResponse = await _groupService.getAllUsers(authService.authToken);
    if (serverResponse.status == ServerResponse.SUCCESS) {
      _users = serverResponse.result;

      notifyListeners();
    }
  }
 Future<void>  setAdmins(BuildContext context) async{
    while(isLoading){
      await Future.delayed(Duration(seconds: 1));
      print("waiting");
    }

      _presedent = _users.firstWhere((element) => element.userId ==
          _group?.currentPresedent);
      _secretary = _users.firstWhere((element) => element.userId ==
          _group?.currentSecretary);
      _treasurer = _users.firstWhere((element) => element.userId ==
          _group?.currentTresurer);

    for (var i = 0; i < _users.length; i++) {
      print(_users[i]);
      // if(_users[i].userId == _group?.currentPresedent){
      //   _presedent = _users[i];
      // }
      // if(_users[i].userId == _group?.currentSecretary){
      //   _secretary = _users[i];
      // }
      // if(_users[i].userId == _group?.currentTresurer){
      //   _treasurer = _users[i];
      // }
    }
      isAdminsLoading = false;
      print("setAdmins");
      notifyListeners();


  }
  // Future<void> fetchAdmins(BuildContext context)async{
  //   AuthProvider authService = Provider.of<AuthProvider>(context, listen: false);
  //   ServerResponse serverResponse = await _userService.getAllUsers(authService.authToken);
  //   ServerResponse s1 = await _groupService.getGroup(authService.authToken);
  //   if (serverResponse.status == ServerResponse.SUCCESS) {
  //     // _users = serverResponse.data;
  //     notifyListeners();
  //   }
  // }
  List<User> getUsers() {
    return _users;
  }
  Group getGroup() {
    return _group!;
  }
}
