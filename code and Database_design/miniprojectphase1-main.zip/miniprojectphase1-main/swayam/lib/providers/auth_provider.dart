import 'package:swayam/models/server_response.dart';
import 'package:swayam/models/user.dart';
import 'package:swayam/providers/user_provider.dart';
import 'package:swayam/services/auth_service.dart';
import 'package:swayam/services/user_service.dart';

class AuthProvider{
  final authService = new AuthService();
  User loggedInUser = User();
  String loggedPassword = "";
  String futureLoginUserName = "";
  String futureLoginPassword = "";
  String authToken = "";

  Map<String, dynamic> loginHandlers = {};
  Map<String, dynamic> logoutHandlers = {};

  update(userProvider) {
    if (this.loggedInUser != null &&
        this.loggedInUser.username != null &&
        this.loggedPassword != null) {
      login(loggedInUser.username, loggedPassword);
    } else {
      print('Expired Auth is occuring without prior login..should never have occured');
    }
  }

  addLoginHandler(String key, dynamic function) {
    loginHandlers[key] = function;
  }

  addLogoutHandler(String key, dynamic function) {
    logoutHandlers[key] = function;
  }

  callLoginHandlers() {
    for (dynamic handler in loginHandlers.values) {
      if (handler != null) {
        handler();
      }
    }
  }

  callLogoutHandlers() {
    for (dynamic handler in logoutHandlers.values) {
      if (handler != null) {
        handler();
      }
    }
  }

  login(userName, password, {loggedInEarlier = false}) async {
    if (true) {
      ServerResponse serverResponse =
      await authService.login(userName, password);
      print(serverResponse.status);
      if (serverResponse.ifSuccess()) {
        authToken = serverResponse.authToken;
        print(authToken);
        loggedInUser = User.fromJson(serverResponse.data);
        loggedPassword = password;
        print(loggedInUser);
        callLoginHandlers();
      }
      return serverResponse;
    }
  }

  logout() {
    print('****LogOut is called');
    callLogoutHandlers();
    loggedInUser = User();
    authToken = "";
    loggedPassword = "";
  }

  bool canUpdate(User targetUser) {
    if (this.loggedInUser.username == targetUser.username){
      return true;
    }
    return false;
  }

  bool canDelete(User targetUser) {
    if (this.loggedInUser.username == targetUser.username) {
      return false;
    }
    return false;
  }
}
