import 'package:swayam/models/user.dart';
import 'package:swayam/providers/auth_provider.dart';
import 'package:swayam/models/server_response.dart';
import 'package:flutter/widgets.dart';
import 'package:swayam/common/date.dart';
import 'package:swayam/common/constants.dart';
import 'package:swayam/services/user_service.dart';
import 'package:provider/provider.dart';
import 'dart:convert';
import 'dart:developer' as developer;

class UserProvider{

  AuthProvider _auth = AuthProvider();
  String authToken = "";
  UserProvider();
  bool _cachePopulated = false;

  logoutHandler() {
    users.clear();
    userMap.clear();
  }

  loginHandler() async {
    if (_auth.loggedInUser.firstname.length> 0){
      await getAllUsers();
    }
    addOrUpdateToCacheDB(_auth.loggedInUser);
  }

  final UserService userService = UserService();
  List<User> users = [];
  Map<String, User> userMap = {};

//=====================================================================================================================================

  Future<ServerResponse> createUser(User user, String authToken) async {
    ServerResponse serverResponse;
    print("createUser dart UserProvider");
    if (_auth != null && _auth.authToken != null) {
      serverResponse = await userService.createUser(user, _auth.authToken);
    } else {
      print(_auth.authToken);
      serverResponse = await userService.createUser(user, authToken);
    }
    print("point");
    if (serverResponse.ifSuccess()) {
      addOrUpdateToCacheDB(serverResponse.result);
    }
    return serverResponse;
  }

  //=====================================================================================================================================

  Future<ServerResponse> getAllUsers() async {
    ServerResponse serverResponse = ServerResponse(ServerResponse.INITIATE, '');

    if (users != null && users.length > 0 && _cachePopulated) {
      serverResponse = ServerResponse(ServerResponse.SUCCESS, 'Success');
      serverResponse.result = users;
      return serverResponse;
    }
    if (users.length == 0 || users == null) {
      serverResponse = await userService.getAllUsers(_auth.authToken);
      await processFetchedEntities(serverResponse.result, addOnEmpty: true);
    }
    if (users != null && users.length > 0) {
      serverResponse = ServerResponse(ServerResponse.SUCCESS, 'Success');
      serverResponse.result = users;
      _cachePopulated = true;
    }
    else if (serverResponse != null) {
      serverResponse =
          ServerResponse(ServerResponse.FAILED, 'Failed to get users');
    }
    return serverResponse;
  }

  //=====================================================================================================================================

  Future<ServerResponse> updatePassword(User userParam) async {
    ServerResponse serverResponse = ServerResponse(ServerResponse.INITIATE, '');
    if (this._auth.authToken != null) {
      serverResponse =
      await userService.updatePassword(userParam, this._auth.authToken);
    } else if (this.authToken != null) {
      serverResponse = await userService.updatePassword(userParam, this.authToken);
    }
    return serverResponse;
  }

  //=====================================================================================================================================

  Future<ServerResponse> updateUser(User userParam) async {
    ServerResponse serverResponse = await userService.updateUser(userParam, _auth.authToken);
    if (serverResponse.ifSuccess()) {
      if (serverResponse.result.username == _auth.loggedInUser.username) {
        _auth.loggedInUser = serverResponse.result;
      }
      addOrUpdateToCacheDB(serverResponse.result);
    }
    return serverResponse;
  }

  //=====================================================================================================================================

  Future<ServerResponse> deleteUser(String username) async {
    ServerResponse serverResponse =
    await userService.deleteUser(username, this._auth.authToken);
    if (serverResponse.ifSuccess()) {
      removeUserFromCache(username);
    }
    return serverResponse;
  }

  getUser(String username) {
    return userMap[username];
  }

  //=====================================================================================================================================

  addOrUpdateToCacheDB(User user, {addOnEmpty = false}) async {
    if (users.length > 0 || addOnEmpty) {
      if (getUser(user.username) == null) {
        addUserToCache(user);
      } else {
        replaceUserInCache(user);
      }
    }
  }

  //=====================================================================================================================================

  addUserToCache(User user) {
    this.users.add(user);
    this.userMap[user.username] = user;
  }

  //=====================================================================================================================================

  replaceUserInCache(User user) {
    removeUserFromCache(user.username);
    addUserToCache(user);
  }

  //=====================================================================================================================================

  removeUserFromCache(String username) {
    for (int a = 0; a < users.length; a++) {
      if (users[a].username == username) {
        users.removeAt(a);
        break;
      }
    }
    userMap.remove(username);
  }

  //=====================================================================================================================================

  deleteFromCacheDB(String username) async {
    removeUserFromCache(username);
  }

  //=====================================================================================================================================

  processFetchedEntities(List fetchedUsers, {addOnEmpty = false}) async {
    if (fetchedUsers == null || fetchedUsers.length == 0) {
      return;
    }
    if (addOnEmpty) {
      Map<String, String> entityMap = Map();
      for (User user in fetchedUsers) {
        addUserToCache(user);
        entityMap[user.username] = json.encode(user.toJson());
      }
      entityMap.clear();
    } else {
      for (User user in fetchedUsers) {
        if (user.statusId == 1) {
          await addOrUpdateToCacheDB(user, addOnEmpty: addOnEmpty);
        } else {
          await deleteFromCacheDB(user.username);
        }
      }
    }

    fetchedUsers.clear();
  }

  //=====================================================================================================================================

  update(AuthProvider authProvider) {
    _auth = authProvider;
    _auth.addLogoutHandler("UserProvider", logoutHandler);
    _auth.addLoginHandler("UserProvider", loginHandler);
  }
}