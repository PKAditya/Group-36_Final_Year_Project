import 'package:flutter/material.dart';
import 'package:swayam/providers/group_provider.dart';
// import 'package:swayam/screens/login/LogIn.dart';
import 'package:swayam/screens/login/login_with_username.dart';
// import 'screens/shg/members/member_details.dart';
// import 'screens/shg/members/addmem.dart';
// import 'screens/shg/members/edit_member_details.dart';
// import 'package:swayam/screens/shg/shg_management/shgManagement.dart';
// import 'package:swayam/screens/shg/shg_management/shgdetails.dart';
// import 'package:swayam/screens/shg/shg_management/edit_shg_details.dart';
import 'package:provider/provider.dart';
import 'package:swayam/providers/auth_provider.dart';
import 'package:swayam/providers/user_provider.dart';
import 'package:swayam/screens/homescreen/homescreen.dart';
import 'package:swayam/providers/shared_preferences_provider.dart';
void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider(create: (_) => AuthProvider(), lazy: false),

        ChangeNotifierProvider(create: (context) => GroupProvider(context),

        ),
        Provider(
          create: (_) => SharedPreferencesProvider(),
          lazy: false,
        ),
        ProxyProvider<AuthProvider, UserProvider>(
          create: (context) => UserProvider(),
          update: (_, authProvider, userProvider) =>
              userProvider!..update(authProvider),
        )
      ],
      child: MaterialApp(
        title: 'Swayam',
        debugShowCheckedModeBanner: false,
        // theme: ThemeData(primaryColor: Color(0xff622F74)),
        initialRoute: '/login',
        theme: ThemeData(fontFamily: "Prompt",primarySwatch:Colors.purple),
        routes: {
          '/': (context) => homescreen(),
          '/login': (context) => Login(),
          // '/shg-management': (context) => ShgManagement(),
          // '/shg-details': (context) => ShgDetails(),
          // '/edit-shg-details': (context) => EditShgDetails(),
          // '/member-details': (context) => MemberDetails(),
          // '/add-member': (context) => AddMember(),
          // '/edit-member-details': (context) => EditMemberDetails(),
        },
      ),
    );
  }
}