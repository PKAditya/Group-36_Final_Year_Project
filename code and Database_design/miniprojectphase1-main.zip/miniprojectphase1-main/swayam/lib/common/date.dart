import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class DateUtil{
  static String getDateTimeString(DateTime date){
    return "${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute}";
  }
  static String getDateTimeDetail(DateTime date){
    return "${date.day}/${date.month}/${date.year} ${date.hour}:${date.minute}:${date.second}.${date.microsecond}";
  }
  static String getDateTime(DateTime date){
    return "${date.day}/${date.month}/${date.year}";
  }
  static String getFormattedDateTimeString(DateTime date, context){
    MaterialLocalizations _localizations = MaterialLocalizations.of(context);
    String time = _localizations
        .formatTimeOfDay(TimeOfDay(hour: date.hour, minute: date.minute));
    String d = DateFormat.yMMMd().format(date);

    return d + ", " + time;
  }
}


