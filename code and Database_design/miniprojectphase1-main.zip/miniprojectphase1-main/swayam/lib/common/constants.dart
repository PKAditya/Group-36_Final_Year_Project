class Constants{
  Constants();
  static const String SERVER_BARE = '10.113.7.248:3456';
  static String SERVER = "http://$SERVER_BARE";
  static const double DEFAULT_LAT = 9.0929463;
  static const double DEFAULT_LNG = 76.4850891;
  static const double DEFAULT_ZOOM = 9;
}
