class Group{
  Group();
  late int groupId;
  String groupName = "";
  String dof = "";
  int houseNo = 0;
  int currentSecretary=0;
  int currentTresurer=0;
  int currentPresedent=0;
  String town = "";
  String district = "";
  String pinCode = "";
  int totalMembers = 0;
  int statusId = 0;
  int clusterId = 0;
  String bank_account_creation_date="";
  String bank_account_num="";
  late int bank_branch_id;
  String doc = "";
  String sg_RegNo="";
  String old_RegNo="";
  String panchayat="";

  // int groupId = 0;
  clone(){
    return Group.fromJson(this.toJson());
  }



  Group.fromJson(Map<String, dynamic>json){
    groupId = json['groupId'];
    groupName = json['groupName'];
    dof = json['dof'];
    houseNo = json['houseNo'];
    currentSecretary = json['currentSecretary'];
    currentTresurer = json['currentTresurer'];
    currentPresedent = json['currentPresedent'];
    town = json['town'];
    district = json['district'];
    pinCode = json['pinCode'];
    totalMembers = json['totalMembers'];
    statusId = json['statusId'];
    clusterId = json['clusterId'];
    bank_account_creation_date=json['bank_account_creation_date'];
    bank_account_num=json['bank_account_num'];
    bank_branch_id=json['bank_branch_id'];
    doc = json['doc'];
    sg_RegNo=json['sg_RegNo'];
    old_RegNo=json['old_RegNo'];
    panchayat=json['panchayat'];

  }
  Map<String,dynamic> toJson(){
    Map<String,dynamic> groupJson={
      'groupId' : groupId,
      'groupName' : groupName,
      'dof' : dof,
      'houseNo' : houseNo,
      'currentSecretary' : currentSecretary,
      'currentTreasurer' : currentTresurer,
      'currentPresident' : currentPresedent,
      'town' : town,
      'district' : district,
      'pinCode' : pinCode,
      'totalMembers' : totalMembers,
      'statusId' : statusId,
      'clusterId' : clusterId,
      'bank_account_creation_date':bank_account_creation_date,
      'bank_account_num':bank_account_num,
      'bank_branch_id':bank_branch_id,
      'doc' : doc,
      'sg_RegNo':sg_RegNo,
      'old_RegNo':old_RegNo,
      'panchayat':panchayat,

    };
    return groupJson;
  }
}