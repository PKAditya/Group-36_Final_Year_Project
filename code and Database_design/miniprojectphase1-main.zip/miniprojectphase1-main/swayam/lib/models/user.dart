class User{
  User();
  late int userId;
  String firstname = "";
  String lastname = "";
  String username = "";
  String password = "";
  String dob = "";
  String houseNo = "";
  String streetName = "";
  String town = "";
  String district = "";
  String pinCode = "";
  String phoneNumber = "";
  int statusId = 0;
  int groupId = 0;
  String role="";
  clone(){
    return User.fromJson(this.toJson());
  }

  User.fromJson(Map<String, dynamic>json){
    userId = json['userId'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    username = json['username'];
    password = json['password'];
    dob = json['dob'];
    houseNo = json['houseNo'];
    streetName = json['streetName'];
    town = json['town'];
    district = json['district'];
    pinCode = json['pinCode'];
    phoneNumber = json['phoneNumber'];
    statusId = json['statusId'];
    groupId = json['groupId'];
    role=json['role'];
  }

  Map<String,dynamic> toJson(){
    Map<String,dynamic> userJson={
      'firstname' : firstname,
      'lastname' : lastname,
      'username' : username,
      'password' : password,
      'dob' : dob,
      'houseNo' : houseNo,
      'streetName' : streetName,
      'town' : town,
      'district' : district,
      'pinCode' : pinCode,
      'phoneNumber' : phoneNumber,
      'statusId' : statusId,
      'groupId' : groupId,
      'role':role
    };
    return userJson;
  }
}