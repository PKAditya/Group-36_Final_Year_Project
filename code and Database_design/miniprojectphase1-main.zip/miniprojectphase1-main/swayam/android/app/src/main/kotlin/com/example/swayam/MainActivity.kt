package com.example.swayam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
